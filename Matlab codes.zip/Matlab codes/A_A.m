%% 附录A Matlab编程简单语法

% 双精度计算
x = 10001 / 1001
y = pi
z = sqrt(2)

% 可变精度计算
vpa(10001 / 1001)
vpa(10001 / 1001, 8)

% 符号计算
x = sym(pi)
y = sqrt(sym(2))

% 大数计算
Z = 80435758145817515
Z1 = sym(80435758145817515)
Z2 = sym('80435758145817515')
sym('3')^100

% 求方程解析解
syms a b c x
eqn = a*x^2 + b*x + c == 0;       % 注意方程中的=要用==
sols = solve(eqn, x)

solsSym = subs(sols,[a b c],[1 4 2])  % 代入数值
solsDouble = double(solsSym)          % 转化数值
digits(10);                           % 设置全局有效数字位数
solsVpa = vpa(solsSym)

% 匿名函数
V_cylinder = @(r, h) pi * r^2 * h
V_cylinder(2,3)   

% 符号函数绘图
t = 0:0.01:4*pi;
plot(t, sin(t), 'b.')

syms x
fplot(sin(x), [0,4*pi])  
% 或者直接用 fplot(@(x) sin(x), [0, 4*pi]) 

syms x y
fimplicit(x^2 + y^2 == 25, [-6 6])
axis square

% 元胞数组
a = {'hello' [1 2 3; 4 5 6]; 1 {'1' '2'}}  
    % 创建2×2的元胞数组，
    % 同行元素间用“, 或空格”隔开
    % 行与行间用“;”隔开
    % 第1行第1列的元胞，存放字符串'hello'；
    % 第1行第2列的元胞，存放一个2×3矩阵
    % 第2行第1列的元胞，存放数 1
    % 第2行第2列的元胞，存放1×2元胞数组
    
a{1,1} = 'hello';
    a{1,2} = [1 2 3; 4 5 6]; 
    a{2,1} = 1;
    a{2,2} =  {'1' '2'};
    
a = cell(2,3)      % 生成2×3的空元胞数组

% a{i,j}返回第i行第j列元胞的数据内容
% a(i,j)返回第i行第j列的元胞整体概览

% a(i,:) = []; 删除a的第i行
% celldisp(a) 显示元胞数组a中各元胞的内容
% cellfun(fun,a) 将函数fun分别做用在元胞数组a的每个元素上





