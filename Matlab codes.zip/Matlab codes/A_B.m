%% 附录B 测试二分法求根
% f = @(x) x^3 + 4 * x^2 - 10;
% [root, n, error] = Bisection(f, 1, 2, 0.001)
clc
clear
f = @(a) 0.35 * 3^(a-1) * exp(1-a) / ((3/(a-1))^a * gamma(a)) - 0.1081733;
[root, n, error] = Bisection(f, 0, 8, 1e-8)
