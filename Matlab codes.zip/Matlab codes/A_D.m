%% 附录D Logistic分叉与混沌

n = 100;
% 第1组模拟
x0 = 0.4;
mu = 2.8;
x = Logisticf(x0, mu, n);
plotLogistic(x, mu)

% 第2组模拟
x0 = 0.4; 
mu = 3.2;
x = Logisticf(x0, mu, n);
plotLogistic(x, mu)

% 第3组模拟
x0 = 0.4;
mu = 3.52;
x = Logisticf(x0, mu, n);
plotLogistic(x, mu)

% 第4组模拟
x0 = 0.4;
mu = 3.56;
x = Logisticf(x0, mu, n);
plotLogistic(x, mu)

function x = Logisticf(x0, mu, n)
  x = zeros(n, 1);
  x(1) = x0;
  for i = 2:n
      x(i) = mu * x(i-1) * (1 - x(i -1));
  end
end

function plotLogistic(x, mu)
  n = length(x);
  figure
  subplot(1, 2, 1)
  plot(x, 'k-o')
  axis([0 n 0 1])
  axis square
  text(0.5, 0.1, ['\mu = ', num2str(mu) , ', x_0 = 0.4'])
  subplot(1, 2, 2)
  xx = repelem(x,2);
  line(xx(2:end), xx(1:end-1))
  hold on
  axis([0 1 0 1])
  axis square
  h = line([0 1], [0 1]);
  set(h, 'color', 'r')
  x = 0:0.01:1;
  y = mu * x .* (1-x);
  plot(x, y, 'r--')
end



