%%  附录E MATLAB求解线性规划
clc
clear
f = [-100; -60];
A = [5 2; 4 3; 3 4];
b = [270; 250; 200];
Aeq = [4 -1];
beq = 0;
lb = zeros(2,1);
x0 = rand(2,1);
[x, val, flag] = linprog(f, A, b, Aeq, beq, lb, [], x0)

x = optimvar('x', 2, 'LowerBound', 0);
obj = 100 * x(1) + 60 * x(2);
prob = optimproblem('Objective', obj, 'ObjectiveSense','max');
prob.Constraints.c1 = 5 * x(1) + 2 * x(2) <= 270;
prob.Constraints.c2 = 4 * x(1) + 3 * x(2) <= 250;
prob.Constraints.c3 = 3 * x(1) + 4 * x(2) <= 200;
prob.Constraints.c4 = x(2) == 4 * x(1);
problem = prob2struct(prob);
[x, fval, flag] = linprog(problem)