function [r, n, err] = Bisection(f, a, b, tol, N)
% 输入: 函数f，区间端点a,b, 误差限tol，最大迭代次数N, 默认N=100
% 输出: 近似根r, 迭代次数, 误差
if (nargin == 4)
    N = 100;
end
fa = feval(f, a);
fb = feval(f, b);
if fa * fb > 0      % 如果同号，则无零点
    disp('函数在[a,b]区间上无解!');
    return
end
for i = 1:N
    x = (a+b)/2;
    fx = feval(f,x);
    if fx == 0
        r = x;
        return
    end
    if fa * fx < 0
        b = x;
        fb = fx;
    else
        a = x;
        fa = fx;
    end
    r = (a + b) / 2;
    err = abs(fx);
    if err < tol
        n = i;
        return
    end
end