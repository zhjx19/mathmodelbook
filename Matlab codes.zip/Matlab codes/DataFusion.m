function [a,w]=DataFusion(x)
% x为长度≥2的行向量, 返回a为融合值, w为权重向量
Lx = length(x);
if Lx == 2
    a = mean(x);
    w = [1/2,1/2];
else
    IndCom = nchoosek(1:Lx,2);                 % x中元素下标索引的所有两两组合方式
    d = abs(x(IndCom(:,1)) - x(IndCom(:,2)));  % 计算任意两值之间的距离
    maxd = max(d);
    [Y,X] = meshgrid(1:Lx,1:Lx);
    R = cos(pi*(x(X)-x(Y)) / (2*maxd));          % 构造支持度矩阵
    [V,D] = eig(R);
    w = V(:,Lx) / sum(V(:,Lx));
    a = x*w;
end