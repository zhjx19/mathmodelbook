function [pre,f, lambda, range, phi, rho] = GM11(x)
%% 实现GM(1,1)算法，输入原始序列数据
% 返回第n+1个预测值pre，预测函数f,级比lamda,可容覆盖范围range,相对残差phi,级比偏差rho
% 级比检验
n = length(x);
lambda = x(1:n-1)./x(2:n);                            % 计算级比
range = [exp(-2/(n+1)),exp(2/(n+2))];                 % 可容覆盖的范围
if range(1) < min(lambda) & max(lambda) < range(2)
    disp('级比检验通过');
else
    disp('级比检验未通过');
end
% GM(1,1)建模
x1 = cumsum(x);                                         % 一次累加
n = length(x1);
z1 = (x1(1:n-1) + x1(2:n)) / 2;
Y = x(2:n)';                                            % 构造矩阵Y
B = [-z1', ones(n-1,1)];                                % 构造矩阵B
A = (B'*B)\B'*Y;                                        % 计算模型的参数a,b
k=1:n;
x1=(x(1)-A(2)/A(1))*exp(-A(1)*(k-1))+A(2)/A(1);         % 利用模型计算累加值的预测值
x_p=[x(1), diff(x1)];                                   % 累减还原到预测值
Delta = abs(x_p-x);                                     % 绝对残差序列
phi = Delta./x;                                         % 相对残差序列
if max(phi) >= 0.2
    disp('相对残差检验未通过');
else
    disp('相对残差检验通过');
end 
rho = 1-(1-0.5*A(1))/(1+0.5*A(1))*lambda;                % 计算级比偏差值
if max(rho) >= 0.2
   disp('级比偏差检验未通过');
else
    disp('级比偏差检验通过');
end 
f = @(t) (x(1)-A(2)/A(1))*(1-exp(A(1)))*exp(-A(1)*t);    % 预测公式
pre = f(n);                                              % 预测第n+1个数据