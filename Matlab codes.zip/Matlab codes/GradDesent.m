function [beta, loss, iter, fitted, RMSE] = GradDesent(X, y, init, eta, maxit, err)
% X 为自变量数据矩阵, y 为因变量向量, init 为参数初始值, eta 为学习率
% err 为误差限, maxit 为最大迭代次数, adapt 是否自适应修改学习率
% 返回回归系数估计, 损失向量, 迭代次数, 拟合值, RMSE
switch nargin
    case 4
        maxit = 1000;
        err = 1e-3;
    case 5
        err = 1e-3
end
% 初始化
[n,m] = size(X);
X = [ones(n,1), X];
beta = init;
loss = norm(X * beta - y);
tol = 1;
iter = 1;
while tol > err & iter < maxit
    fitted = X * beta;
    grad = X' * (fitted - y);
    betaC = beta - eta * grad;
    tol = max(abs(betaC - beta));
    beta = betaC;
    loss = [loss; norm(fitted - y)];
    iter = iter + 1;
    if loss(iter) < loss(iter - 1)
        eta = eta * 1.2;
    else
        eta = eta * 0.8;
    end
end
RMSE = sqrt(norm(fitted - y) / (n - m - 1));

    