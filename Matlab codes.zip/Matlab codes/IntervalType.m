function y = IntervalType(x,a,b)
% 区间型数据转换, [a,b]为最优区间
M = max(a-min(x), max(x)-b);
n = size(x);
for i=1:n
    if x(i) < a
        y(i) = 1 - (a-x(i))/M;
    elseif x(i) <= b
        y(i) = 1;
    else
        y(i) = 1 - (x(i)-b)/M;
    end
end
y = y';
