function y = MiddleType(x,m)
% 居中型数据转换, m为唯一的最优值
M = max(x - m);
y = 1 - abs(x - m) / M;