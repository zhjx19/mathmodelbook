function B = fce(A, R, type)
% 实现模糊合成算子的计算
% A为因素集各因素的权重(列)向量, R为模糊评价矩阵, 要求R的列数等于A的行数
% type选择模糊合成算子的类型, 1-5分别对应前文的5种不同算子
% B返回归一化的综合评价结果
[m,n] = size(R);  
B = zeros(m,1);
for j=1:m
    switch type
        case 1       % 取小取大，主因素决定型
            B(j) = max(min([A'; R(j,:)]));               
        case 2       % 乘积最大，主因素突出型
            B(j) = max(A' .* R(j,:));  
        case 3       % 乘加，加权平均型
            B(j) = sum(A' .* R(j,:));    
        case 4        % 取小上界和型
            B(j) = min(1, sum(min([A'; R(j,:)])));
        case 5        % 均衡平均型
            r0 = sum(R(j,:));
            B(j) = sum(min([A'; R(j,:) ./ r0]));
    end         
end
B = B ./ sum(B);         % 归一化
