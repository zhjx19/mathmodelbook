function r = gray_corr(ck,bj,rho,w)
% 计算灰色关联度
% ck为参考序列, bj为比较序列, rho为分辨系数
% w为加权关联度的权重向量
[n,m] = size(bj);
if (nargin == 3)    
    w = ones(1,n) / n;
end
for j=1:m                      % 每个比较序列与参考序列作差
    t(:,j) = bj(:,j) - ck;
end
min2 = min(min(abs(t)));       % 求两级最小差
max2 = max(max(abs(t)));       % 求两级最大差
eta = (min2 + rho*max2) ./ (abs(t) + rho*max2);  % 求关联系数
r = w * eta;   
