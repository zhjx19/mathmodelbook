function y = guiyi(x, type, a, b)
% 将向量x归一化到[a,b], 默认[0,1], type=1正向指标(默认), type=2负向指标
if (nargin == 1)
    type = 1;
    a = 0; b = 1;
end
if (nargin == 2)    
    a = 0; b = 1;
end
m = min(x);
M = max(x);
if type == 1
    y = (b-a) * (x-m)/(M-m) + a;
else
    y = (b-a) * (M - x)/(M-m) + a;
end