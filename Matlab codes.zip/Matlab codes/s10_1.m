%% 线性回归
%% 一元线性回归
dat = readtable('datas/Salary_Data.csv','PreserveVariableNames',true);
dat(1:3,:)
scatter(dat.Year,dat.Salary,'*')
% mdl = fitlm(dat, 'linear');
rl = refline;
rl.Color = 'red';
rl.LineWidth = 1.25;
line([8.2 8.2],[10.3282 11.3812],'Color','red','LineStyle',':','LineWidth',1.5);

% 正规方程法
x = dat.Year;
X = [ones(length(x),1) x];
y = dat.Salary;
beta = X \ y

% 多元线性回归案例
dat = readtable('datas/Predict_Profit.xlsx', 'PreserveVariableNames',true);
summary(dat)
R = corr(dat{:,[1:3,5]})                   % 相关系数矩阵

% 检验多重共线性
VIF = @(X) diag(inv(corr(X)));             % 定义计算VIF的函数
VIF(dat{:,1:3})
collintest(dat{:,1:3},'plot','on')         %  Belsley共线性诊断

lm = fitlm(dat);
lm = fitlm(dat,'linear');
lm = fitlm(dat,'Profit~RD_Spend+Administration+Marketing_Spend+State')
lm = fitlm(dat,'Profit~RD_Spend+Administration+Marketing_Spend+State','CategoricalVars','State')

% 虚拟变量处理
tabulate(dat.State)
dat.State = categorical(dat.State);    % 先转化为分类变量
dummyvar(dat.State)                    % 将分类变量转化为虚拟变量

lm.Coefficients                   % table: 回归系数及统计量
coefCI(lm)                        % 回归系数95%置信区间
CM = lm.CoefficientCovariance     % 系数协方差矩阵
SE = diag(sqrt(CM))               % 回归系数标准误
[p,F,d] = coefTest(lm)            % 模型系数假设检验
anova(lm)                         % 模型的ANOVA表
anova(lm,'summary')               % 模型汇总ANOVA表
lm.SSE,lm.SSR,lm.SST
lm.Rsquared.Ordinary,lm.Rsquared.Adjusted

% 残差诊断
dwtest(lm)                        % DW残差独立性检验
plotResiduals(lm)                 % 残差直方图
plotResiduals(lm,'probability')   % 残差Q-Q图
plotResiduals(lm,'fitted')        % 残差图

% 异常检验
plotDiagnostics(lm,'cookd')       % Cook's距离诊断异常值
CooksD = lm.Diagnostics.CooksDistance;
find((CooksD) > 3*mean(CooksD))   % 找出异常样本
plotDiagnostics(lm)               % 高杠杆值诊断
HLs = lm.Diagnostics.Leverage;
find(HLs > 2*6/49)                % 找出异常样本

% 模型预测
RD_Spend = [15;8];
Administration = [10;15];
Marketing_Spend = [20;40];
State = {'New York';'Florida'};
newdat = table(RD_Spend,Administration,Marketing_Spend,State);
feval(lm,newdat)
