clc
clear

%% 梯度下降法
rng(123);
x1 = randn(1000,1);
x2 = randn(1000,1);
y = 1 + 0.6*x1 - 0.2*x2 + randn(n,1);

X = [x1, x2];
[beta, loss, iter, fitted, RMSE] = GradDesent(X, y, [0;0;0], 1e-4, 1000, 1e-8);
beta, iter, RMSE
plot(1:iter, loss, 'o-'), grid on
xlabel('迭代次数'), ylabel('损失')

% 与fitlm对比
lm = fitlm(X, y);
lm.Coefficients.Estimate

%% 非线性拟合
x = [2 3 4 5 7 9 12 14 17 21 28 56]'; 
r = rand(12,1) - 0.5; 
y= [35 42 47 53 59 65 68 73 76 82 86 99]' + r;
fun = @(beta,x) beta(1)+beta(2)*exp(beta(4)*x)+beta(3)*exp(-beta(4)*x);
[beta,err,J] = nlinfit(x, y, fun, rand(1,4));   
beta                                            % 拟合系数估计
[yfit,delta] = nlpredci(fun,x,beta,r,J)
plot(x,y,'*', x, yfit,'r')

%% 插值拟合
f1 = fit(x,y,'linearinterp');                   % 线性插值
X = 0:60;
plot(x,y,'*',X,f1(X),'-'), grid on

f2 = fit(x,y,'cubicinterp');                   % 三次样条插值
X = 0:60;
plot(x,y,'*',X,f2(X),'-'), grid on
%% 一元多项式回归
pop = readtable('我国人口数据.xlsx','PreserveVariableNames',true);
plot(pop.Year,pop.Population,'*'), grid on
[P,S] = polyfit(pop.Year,pop.Population,2)             % 二次多项式回归
x1 = 1995:0.5:2014;
y1 = polyval(P,x1,S);                                
hold on 
plot(x1,y1,'-r') 
legend('原数据散点图','二次多项式拟合曲线');
polyval(P, 2015:2020)                                  % 预测2015-2020年的人口

%% 二元多项式回归
dat = readtable('Predict_Profit.xlsx', 'PreserveVariableNames',true);
dat(:,[2,4]) = [];
lm2 = fitlm(dat,'quadratic')

%% 逐步回归
dat = readtable('Predict_Profit.xlsx', 'PreserveVariableNames',true);
lm3 = stepwiselm(dat, 'quadratic')