clc
clear
%% Logistic回归
dat = dlmread('FearfulAngry.txt'); 
x = dat(:,1);
y = dat(:,2);
 
lm = fitlm(x, y);                          % 拟合线性回归模型
xvals = 0:100;
yhat = predict(lm, xvals');                % 模型在新值上做预测
plot(x,y,'*',xvals, yhat,'r'), grid on

% syms x y
% ezplot(1 / (1 + exp(-x)), [-10, 10]), hold on
% plot([-10 10], [1,1], 'r--',[-10 10], [0,0], 'r--'), grid on

glm = fitglm(x, y, 'linear', 'Distribution', 'binomial');
glm
xvals = 1:100;
yhat2 = predict(glm, xvals');
plot(x, y, '*', xvals, yhat2, 'r'), grid on

pred = predict(glm, x);                  % 预测概率值
pred(pred >= 0.5) = 1;                   % 以0.5为阈值
pred(pred < 0.5) = 0;
mean(pred == y)                          % 预测正确率

%% 泊松回归
vc = readtable('ViolentCrimes.csv','PreserveVariableNames',true);
y = vc.nv;
histogram(y,20,'Normalization','pdf'), hold on
[f,yi] = ksdensity(y); 
plot(yi,f)
axis([-1 35 0 0.3])
% kstest(y,[y poisscdf(y,mean(y))])

vc.type = categorical(vc.type,{'C','U'});
vc.region = categorical(vc.region,{'C','S','W','NE','MW'});
vc.log_enroll = log(vc.enroll1000);
plm = fitglm(vc,'nv~type+region','Distribution','poisson','offset','log_enroll')

