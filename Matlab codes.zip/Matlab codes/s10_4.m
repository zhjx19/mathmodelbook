clc
clear
tour = xlsread('datas/北京市接待海外旅游人数.xlsx');
pm = tour(1:end-1, 2:end)';
t = datetime(1997,1,15):calmonths(1):datetime(2002,12,15);
plot(t', pm(:), 'b-'), grid on

py = mean(pm);  % 每年的月均旅游人数
figure
plot(years(1997:2002), py', 'b-'), grid on

%% GM(1,1)预测
[pre,f, lambda, range, phi, rho] = GM11(py)
mu = sum(pm,2) / sum(sum(pm))                    % 行和占总和的比重
pre03 = pre * 12 * mu                            % 预测值

% 用数据融合改进预测
n = length(py);
pres = arrayfun(@(k) GM11(py(n-k:end)), ceil(n/2):n-1);   % 最后一个预测值是用全部数据
pre2 = DataFusion(pres)
pre03f = pre2 * 12 * mu                                   % 融合预测值

% 对比真实值、灰色预测值、融合预测值
rlt = [tour(end,2:end)', pre03, pre03f] 
figure
plot(1:12, rlt), grid on
legend('真实值', '预测值', '融合预测值')