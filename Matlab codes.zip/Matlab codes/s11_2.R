## 11.2 确定性分解

df = readxl::read_xlsx("datas/export_datas.xlsx")
x = ts(df$export, start = c(2001,10), frequency = 12)  # 创建时间序列

xde = decompose(x, type = "additive")
plot(xde) 

xsa = x - xde$seasonal
plot(xsa)

xstl = stl(x, s.window = "periodic")
plot(xstl, labels = c("原数据","季节","趋势","剩余"), main = "")
