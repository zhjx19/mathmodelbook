## 11.3 指数平滑法

df = readxl::read_xlsx("datas/export_datas.xlsx")
x = ts(df$export, start = c(2001,10), frequency = 12)  # 创建时间序列

hw = HoltWinters(x)
hw 
plot(hw)

library(forecast)
pre = forecast(hw, h = 5)
pre
plot(pre)
