## 11.4 SARIMA模型

df = readxl::read_xlsx("datas/export_datas.xlsx")
x = ts(df$export, start = c(2001,10), frequency = 12)  # 创建时间序列
xs = diff(log(x))   # 平稳化处理: 先取对数再做 1 阶差分

acf(xs, lag.max = 40, plot = TRUE)
pacf(xs, lag.max = 40, plot = TRUE)

# 自动定阶
auto.arima(log(x))

# 建模
mdl = Arima(log(x), order = c(0,1,2), 
            seasonal = list(order = c(0,1,1), period = 12)) 
mdl

# 模型检验
plot(mdl$residuals)                # 绘制残差图
acf(mdl$residuals,lag.max = 30)    # 残差自相关性图
Box.test(mdl$residuals, lag = 24, type = "Ljung-Box") 

## 模型预测
library(forecast)
pre = forecast(mdl, h = 5)
pre
plot(pre)

exp(pre$mean)

## lambda
auto.arima(x, lambda = "auto")

mdl2 = Arima(x, order = c(1,1,1), 
             seasonal = list(order = c(0,1,1), period = 12),
             lambda = "auto")



pre2 = forecast(mdl2, h = 5)
plot(pre2)
