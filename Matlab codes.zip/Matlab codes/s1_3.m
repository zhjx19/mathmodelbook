% 定义符号变量
syms kg ka T1 T2 el d Q2 Ta Tb 
% 定义方程组
eqns = [Q2 == kg*(T1-Ta)/d, 
        Q2 == ka*(Ta-Tb)/el, 
        Q2 == kg*(Tb-T2)/d];  
% 求解方程组
S = solve(eqns, [Q2,Ta,Tb]);
S.Q2                                % 解Q2
simplify(S.Q2)                      % 化简表达式

r = @(h) 1 ./ (1 + 8 * h);          % 定义匿名函数
h = 1:5;
1- r(h)                             % 减少热量损失比例

h = 0:0.01:8;
y = r(h);
plot(h, y, 'r-')                     % 绘图，红色实线
grid on                              % 添加网格线
xlabel('h (l/d)'), ylabel('Q1/Q2')   % 设置坐标轴标签
title('热量损失比Q1/Q2与h的关系')     % 设置图形标题

%% 根据基本不再改进法
df = gradient(y, 0.01);              % 计算数值一阶导
n = sum(abs(df) > 0.01) ;            % 找到临界位置
h(n)                                 % 临界h值
r(h(n))                              % r值

%% 肘点法
h = 0.2:0.01:8;
y = r(h);
[xe,ye] = ElbowPoint(h,y)

plot(h, y, 'b-', xe, ye, 'ro')       % 绘图，红色实线
grid on                              % 添加网格线
xlabel('h (l/d)'), ylabel('Q1/Q2')   % 设置坐标轴标签
title('热量损失比Q1/Q2与h的关系')     % 设置图形标题

