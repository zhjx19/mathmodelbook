clc
clear

syms r P(t) t0 P0
eqn = diff(P,t) == r*P;
cond = P(t0) == P0;
PSol(t) = dsolve(eqn, cond)      % 返回符号函数symfun
simplify(PSol(t))

P0 = 1e8;
r = 0.01;
P = @(t) P0 * exp(r * t);
t = 1:1000;
plot(t, P(t), 'b-', 'linewidth', 2)
xlabel('时间'), ylabel('人口数')
grid on

% 美国1790-1930年人口数据(10年为间隔)
P = [3.9, 5.3, 7.2, 9.6, 12.9, 17.1, 23.2, 31.4, ...
     38.6, 50.2, 62.9, 76.0, 92.0, 106.5, 123.2];
year = 1790:10:1930; 
plot(year, P, 'bo')

figure
plot(year, log(P), 'bo')

X = year - 1789;
y = log(P);
mdl = fitlm(X, y)

% 用匿名函数方式来定义预测函数
f = @(t) exp(0.025215 * (t - 1789) + 1.4962);  
Pm = f(year);            % 计算预测值
errs = 100 * abs(Pm - P) ./ P;
result = array2table([year; P; Pm; errs]', 'VariableNames', {'Year', 'P','Pm', 'Error'})

figure
plot(year, P, 'bo', year, Pm, 'r*')
legend('真实值', '预测值')