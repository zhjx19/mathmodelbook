%% SI模型
syms I(t) lambda I0
eqn = diff(I,t) == lambda * I * (1-I);
cond = I(0) == I0;
Isol(t) = dsolve(eqn, cond)

lambda = 5;
I0 = 0.1;
Isol(t) = eval(Isol(t));

ts = 0:0.01:2;
plot(ts, Isol(ts))
hold on
line = refline(0,1);               % 加一条参考线
line.Color = 'r';  
axis([0 2 0 1.1])
xlabel('时间'), ylabel('感染比例')

dI = diff(Isol,1); 
tm = solve(Isol(t)==0.5, t);
eval(tm)
 
figure
plot(ts, dI(ts), tm, dI(tm), 'r*')
xlabel('时间'), ylabel('感染速度')

%% SIS模型
syms I(t) lambda I0 K    % K = 1 - 1/ sigma
eqn = diff(I,t) == lambda * I * (K - I);
cond = I(0) == I0;
Isol(t) = dsolve(eqn, cond)

lambda = 5;
I0 = 0.1;
sigma = 5;
% Isol(t) = subs(Isol(t), K, xm);
K = 1-1/sigma;       % 最大容纳量
Isol(t) = eval(Isol(t));

ts = 0:0.01:2;
plot(ts, Isol(ts))
hold on
line1 = refline(0, 1);
line1.LineStyle = '--';
line = refline(0, 1-1/sigma);       
line.Color = 'r';  
axis([0 2 0 1.1])
xlabel('时间'), ylabel('感染比例')

dI = diff(Isol,1);
tm = solve(Isol(t) == K/2, t);
eval(tm)

figure
plot(ts, dI(ts), tm, dI(tm), 'r*')
xlabel('时间'), ylabel('感染速度')
axis([0 2 0 1])

lambda = 5;
I0 = 0.5;
sigma = 0.8;
xm = 1-1/sigma;                          % 最大容纳量, 即K
Isol(t) = subs(eval(Isol(t)), K, xm);

ts = 0:0.01:2;
figure
plot(ts, Isol(ts))
hold on
line1 = refline(0, 1);
line1.LineStyle = '--';
line = refline(0, 1-1/sigma);             % 加一条参考线
line.Color = 'r';  
axis([0 2 0 1.1])
xlabel('时间'), ylabel('感染比例')