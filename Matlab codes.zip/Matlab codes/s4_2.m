%% SIR模型

% y(1) = S(t), y(2) = I(t)
f = @(t,y,lambda,mu) [-lambda * y(1) * y(2);
                      lambda * y(1) * y(2) - mu * y(2)];

% lambda = 0.6, mu = 0.3, S0 = 0.99, I0 = 0.01                  
lambda = 0.6;
mu = 0.3;
SIRfun = @(t,y) f(t,y,lambda,mu);
y0 = [0.99; 0.01];
tspan = [0, 50];
[t,y] = ode45(SIRfun, tspan, y0);
R = 1 - y(:,1) - y(:,2);
sol = ode45(SIRfun, tspan, y0);
t1 = 1:0.2:2;
deval(sol, t1)              % t必须在tspan范围内

plot(t, y(:,1), t, y(:,2),'r-.', t, R, 'k.');
xlabel('t'), ylabel('y(t)')
legend('S(t)','I(t)','R(t)')
% 相轨线
figure
plot(y(:,1), y(:,2));
xlabel('S(t)'), ylabel('I(t)')

% lambda = 0.5, mu = 0.4, S0 = 0.99, I0 = 0.01
lambda = 0.5;
mu = 0.4;
SIRfun = @(t,y) f(t,y,lambda,mu);
y0 = [0.99; 0.01];
tspan = [0, 50];
[t,y] = ode45(SIRfun, tspan, y0);
R = 1 - y(:,1) - y(:,2);
sol = ode45(SIRfun, tspan, y0);
t1 = 1:0.2:2;
deval(sol, t1)              % t必须在tspan范围内

plot(t, y(:,1), t, y(:,2),'r-.', t, R, 'k.');
xlabel('t'), ylabel('y(t)')
legend('S(t)','I(t)','R(t)')

