%% SEIR模型

% y(1) = S(t), y(2) = E(t), y(3) = I(t)
f = @(t,y,lambda,alpha,gamma) [-lambda * y(3) * y(1);
                                   lambda * y(3) * y(1) - alpha * y(2);
                                   alpha * y(2) - gamma * y(3)];
 
lambda = 0.6;
alpha = 0.5;
gamma = 0.3;
SEIRfun = @(t,y) f(t,y,lambda,alpha,gamma);
S0 = 0.98;
E0 = 0.01;
I0 = 0.01;
y0 = [S0; E0; I0];
tspan = [0, 50];
[t,y] = ode45(SEIRfun, tspan, y0);
R = 1 - y(:,1) - y(:,2) - y(:,3);
 
sol = ode45(SEIRfun, tspan, y0);
t1 = 1:0.2:2;
deval(sol, t1)                              % t必须在tspan范围内

plot(t, y(:,1), t, y(:,2),'r-.', t, y(:,3), 'k.', t, R, 'g'), grid on;
xlabel('t'), ylabel('y(t)')
legend('S(t)', 'E(t)', 'I(t)', 'R(t)')
