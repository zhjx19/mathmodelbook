%% 案例: SARS传播规律

dat = xlsread('datas/SARS_BJ.xlsx');
t = [1:65]';
R = dat(:,3) + dat(:,4);
I = dat(:,1) - R;

subplot(1,2,1)
plot(t, I, 'b*'), grid on
xlabel('t'), ylabel('I(t)')
subplot(1,2,2)
plot(t, R, 'b*'), grid on
xlabel('t'), ylabel('R(t)')

%% 估计参数值
mu = diff(R) ./ I(2:end);
lambda = (diff(I) + diff(R)) ./ I(2:end);

figure
subplot(1,2,1)
plot(t(1:end-1), lambda, 'b.'), grid on
xlabel('t'), ylabel('$$\lambda(t)$$', 'Interpreter','latex')
axis([0 70 -0.05 0.35])
subplot(1,2,2)
plot(t(1:end-1), mu, 'b.'), grid on
xlabel('t'), ylabel('$$\mu(t)$$', 'Interpreter','latex')
axis([0 70 -0.05 0.35])

figure
plot(t(1:end-1), log(lambda), 'b.'), grid on
axis([0 70 -8 -0.5])
fitlm(t(1:20), log(lambda(1:20)))         % 线性拟合

f = @(x) exp(-1.3425 - 0.11433 * x);
figure
plot(t(1:end-1), lambda, 'b.', t, f(t), 'r-'), grid on
xlabel('t'), ylabel('$$\lambda(t)$$', 'Interpreter','latex')
axis([0 70 -0.05 0.35])

figure
plot(t(1:end-1), log(mu), 'b.'), grid on
fitlm(t(15:end-1), log(mu(15:end)))         % 线性拟合

figure
g = @(x) exp(-6.607 + 0.086304 * x);
plot(t(1:end-1), mu, 'b.', t, g(t), 'r-'), grid on
xlabel('t'), ylabel('$$\mu(t)$$', 'Interpreter','latex')
axis([0 70 -0.05 0.35])

% y(1) = I(x), y(2) = R(x)
SIRfun = @(x,y) [(exp(-1.3425-0.11433*x) - exp(-6.4784+0.082829*x)) * y(1);
                  exp(-6.4784+0.082829*x) * y(1)];         
y0 = [I(1); R(1)];
xspan = [0, 80];
[x,y] = ode45(SIRfun, xspan, y0);

figure
subplot(1,2,1)
plot(t, I, 'b.', x, y(:,1), 'r-.'), grid on;
xlabel('t'), ylabel('I(t)');
legend('真实值', '预测值');
subplot(1,2,2)
plot(t, R, 'b.', x, y(:,2), 'r-.'), grid on;
xlabel('t'), ylabel('R(t)');
legend('真实值', '预测值');