clc
clear
H=[4, -4; -4, 8];
f=[-6; -3];
a=[1, 1; 4, 1];
b=[3; 9];
lb = zeros(2,1);
x0 = rand(2,1);
[x,val,flag] = quadprog(H,f,a,b,[],[],lb,[],x0)

x = optimvar('x', 2, 'LowerBound', 0);
obj = 2 * x(1)^2 - 4 * x(1) * x(2) + 4 * x(2)^2 - 6 * x(1) - 3 * x(2);
prob = optimproblem('Objective', obj);
prob.Constraints.c1 = sum(x) <= 3;
prob.Constraints.c2 = 4 * x(1) +  x(2) <= 9;
problem = prob2struct(prob);
[x,fval,flag] = quadprog(problem)