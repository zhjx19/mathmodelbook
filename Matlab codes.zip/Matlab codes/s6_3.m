clc
clear

dat = xlsread('datas/stock_datas.xlsx');
rs = dat(:,2:4) - 1;

ER = mean(rs)          % 期望
COV = cov(rs)          % 协方差矩阵
COR= corrcoef(rs)      % 相关系数矩阵

%% 二次规划模型
[x, val, flag] = quadprog(2*COV,[],-ER,-0.15,ones(1,3),1,zeros(3,1),[],rand(3,1))

%% 根据股票指数简化模型
M = dat(:,5) - 1;
lm1 = fitlm(M, rs(:,1))   % a1, b1
lm2 = fitlm(M, rs(:,1))   % a2, b2
lm3 = fitlm(M, rs(:,1))   % a3, b3

m0 = mean(M)
s0 = std(M)

s1 = sqrt(sum(lm1.Residuals.Raw .^ 2) / (12-2))
s2 = sqrt(sum(lm2.Residuals.Raw .^ 2) / (12-2))
s3 = sqrt(sum(lm3.Residuals.Raw .^ 2) / (12-2))

%% Pareto寻优(加权法)
lam = 0.01:0.01:1;
Revene = zeros(100,1);
Risk = zeros(100,1);
res = cell(100, 2);      % 为元胞数组分配空间
for i=1:100
    H = lam(i) * 2 * COV;
    f = -(1-lam(i)) * ER;
    [x,fval] = quadprog(H,f,[],[],ones(1,3),1,zeros(3,1),[],rand(3,1));
    res{i,1} = x;
    res{i,2} = fval;
    Revene(i) = ER * x;
    Risk(i) = x' * COV * x;
end
% 或者
% for i=1:100
%     x = optimvar('x', 3, 'LowerBound', 0);
%     obj = @(lam) lam * x'*COV*x - (1-lam) * ER*x;
%     prob = optimproblem('Objective', obj(lam(i)));
%     prob.Constraints.c = sum(x) == 1;
%     problem = prob2struct(prob);
%     [x,fval] = quadprog(problem);
%     Revene(i) = ER * x;
%     Risk(i) = x' * COV * x;
% end

plot(Risk, Revene, 'linewidth', 2)
grid on
xlabel('风险'), ylabel('收益')

% fun = @(x)[[x(1),x(2),x(3)]*COV*[x(1);x(2);x(3)]; -ER*[x(1);x(2);x(3)]];
% [x,fval,exitflag] = paretosearch(fun,3,[],[],ones(1,3),1,zeros(3,1),[],[])