%% 8.1 指标数据预处理

%% 指标一致化处理
% x(:,j) = 1 ./ x(:,j);             % 倒数变换
% x(:,j) = max(x(:,j)) - x(:,j);    % 极小极大化变换
% 居中型
PH = 6:9;
MiddleType(PH',7)
% 区间型
T = [35.2;35.8;36.6;37.1;37.8;38.4];
IntervalType(T,36,37)

%% 定性指标量化处理
plot(0:5, 0:0.2:1, '-o', 'LineWidth', 1.5)
set(gca, 'Xtick', 0:5, 'XtickLabel', {'O', '很不满意','不太满意','较满意','满意','很满意'},...
    'Ytick', 0:0.2:1)

syms alpha beta a b
eqns1 = [1 / (1 + alpha * (1 - beta)^(-2)) == 0.01,
        1 / (1 + alpha * (3 - beta)^(-2)) == 0.8];
rlt1 = solve(eqns1, [alpha,beta]);
double([rlt1.alpha, rlt1.beta])

eqns2 = [a * log(3) + b == 0.8,
         a * log(5) + b == 1];
rlt2 = solve(eqns2, [a,b]);
double([rlt2.a, rlt2.b])

f = @(x) 1 ./ (1 + 1.1086 .* (x - 0.8942).^(-2));
x1 = 1:0.1:3;
figure
plot(x1, f(x1), '-b', 'linewidth', 1.5)
hold on
x2 = 3:0.1:5;
g = @(x) 0.3915 .* log(x) + 0.3699;
plot(x2, g(x2), '-r', 'linewidth', 1.5)
set(gca, 'Xtick', 1:5, 'XtickLabel', {'很差','差','一般','好','很好'},...
    'Ytick', 0:0.2:1)
