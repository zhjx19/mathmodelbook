clc
clear

% load Employment.mat
% ind = [1 1 1 1 2];
% [s,w] = shang(X, ind)

% S型动态加权函数