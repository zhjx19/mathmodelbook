clc
clear
X = xlsread('20条河流水质数据.xlsx');
X = X(:,2:5);
%% 数据预处理
X(:,2) = MiddleType(X(:,2),7);
X(:,3) = max(X(:,3)) - X(:,3);
X(:,4) = IntervalType(X(:,4),10,20);
%% 确定权重
ind = ones(1,4);         % 预处理完都是正向指标
[~,w] = shang(X, ind)    % 熵权法赋权
%% TOPSIS法综合评价
f1 = TOPSIS(X,w)
f2 = gray_corr_eval(X,w)
x = 1:20;
plot(x,f1,'-.', x,f2,'-*')