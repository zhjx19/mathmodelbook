%% 8.4 DEA模型
clc
clear

%% 准备数据
dat = xlsread('datas/dea_data.xlsx');
X = dat(:,1:2)';    % 投入指标数据，做转置
Y = dat(:,3:4)';    % 产出指标数据，做转置
n = size(X,2);      % 决策单元数
m = size(X,1);      % 投入指标数
q = size(Y,1);      % 产出指标数

%% 投入导向CCR
w = [];
for i = 1:n
    f = [zeros(1,n) 1];   % 定义目标函数
    Aeq = [];             % 没有等式约束
    beq = [];
    LB = zeros(n+1,1);    % 指定下界
    UB = [];       
    A = [X -X(:,i); -Y zeros(q,1)];         % 设定不等式约束
    b = [zeros(m,1);-Y(:,i)];    
    w(:,i) = linprog(f,A,b,Aeq,beq,LB,UB);  % 模型求解
end
crs_in = w(n+1,:)';                         % 提取结果

%% 产出导向CCR
w = [];
for i = 1:n
    f = [zeros(1,n) -1];    % 定义目标函数
    Aeq = [];
    beq = [];               % 无等式约束
    LB = zeros(n+1,1);      % 指定下界
    UB = [];    
    A = [X zeros(m,1);-Y Y(:,i)];           % 设定不等式约束
    b = [X(:,i)' zeros(1,q)]';    
    w(:,i) = linprog(f,A,b,Aeq,beq,LB,UB);  % 求解模型
end
w = 1./w;                          % 计算效率
crs_out = w(n+1,:)';               % 提取结果 

%% 投入导向BCC
w = [];
for i = 1:n
   f = [zeros(1,n) 1];              % 定义目标函数
   A = [X -X(:,i); -Y zeros(q,1)];  % 指定不等式约束
   b = [zeros(1,m) -Y(:,i)']';   
   Aeq = [ones(1,n) 0];             % 定义等式约束
   beq = 1;   
   LB =[zeros(n+1,1)];              % 指定下界
   UB = [];   
   w(:,i) = linprog(f,A,b,Aeq,beq,LB,UB);   % 模型求解 
end
vrs_in = w(n+1,:)';                 % 提取结果

%% 产出导向BCC
w = [];
for i = 1:n
   f = [zeros(1,n) -1];           % 指定目标函数
   A = [X zeros(m,1);-Y Y(:,i)];  % 指定不等式约束
   b = [X(:,i)' zeros(1,q)]';   
   Aeq = [ones(1,n) 0];           % 指定等式约束
   beq = 1;   
   LB = zeros(n+1,1);             % 指定下界
   UB = [];   
   w(:,i) = linprog(f,A,b,Aeq,beq,LB,UB);     % 模型求解
end
vrs_out = 1./w(n+1,:)';            % 提取结果
 
%% 非期望产出SBM
Y_g = dat(:,3:4)';          % 期望产出指标数据，转置
Y_b = dat(:,5)';            % 非期望产出指标数据，转置
[m,n] = size(X);
s1 = size(Y_g,1);
s2 = size(Y_b,1);
c = 1/(s1+s2);

rho = [];
w = [];

for i = 1:n
    f = [-1./(m*X(:,i)') zeros(1,s1) zeros(1,s2) zeros(1,n) 1];
    A = [];
    b = [];
    UB = [];
    LB = zeros(m+s1+s2+n+1,1);
    
    Aeq = [zeros(1,m) c*1./Y_g(:,i)' c*1./Y_b(:,i)' zeros(1,n) 1;
           eye(m) zeros(m,s1) zeros(m,s2) X -X(:,i);
           zeros(s1,m) -eye(s1) zeros(s1,s2) Y_g -Y_g(:,i);
           zeros(s2,m) zeros(s2,s1) eye(s2) Y_b -Y_b(:,i)]; 
    beq = [1 zeros(m,1)' zeros(s1,1)' zeros(s2,1)']';
    
    [w(:,i) rho(i)] = linprog(f,A,b,Aeq,beq,LB,UB);
end

%% 结果输出
name = {'安徽','北京','福建','甘肃','广东','广西','贵州','海南','河北','河南',...
        '黑龙江','湖北','湖南','吉林','江苏','江西','辽宁','内蒙古','宁夏','青海',...
        '山东','山西','陕西','上海','四川','天津','西藏','新疆','云南','浙江',...
        '重庆'};
 table(crs_in, crs_out, vrs_in, vrs_out, rho', 'RowNames',name,...
     'VariableNames', {'crs_in', 'crs_out', 'vrs_in', 'vrs_out', 'sbm_unOut'})
