clc
clear

subplot(1,2,1);
x = 0:0.1:10;
y = trimf(x,[3 6 8]);
plot(x,y,'linewidth',2), grid on
xlabel('trimf, P = [3 6 8]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,2,2);
y = trapmf(x,[1 5 7 8]);
plot(x,y,'linewidth',2), grid on
xlabel('trapmf, P = [1 5 7 8]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);

figure
x = 0:0.1:10;
y = trapmf(x,[0,0,2,5]);
plot(x,y,'linewidth',2)

subplot(1,3,1)
x = 0:0.1:10;
y = gaussmf(x,[2 5]);
plot(x,y,'linewidth',2), grid on
xlabel('gaussmf, P=[2 5]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,3,2)
y = gauss2mf(x,[1 3 3 4]);
plot(x,y,'linewidth',2), grid on
xlabel('gauss2mf, P=[1 3 3 4]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,3,3)
y = gbellmf(x,[2 4 6]);
plot(x,y,'linewidth',2), grid on
xlabel('gbellmf, P=[2 4 6]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);

subplot(1,3,1)
x = 0:0.1:10;
y = sigmf(x,[2 4]);
plot(x,y,'linewidth',2), grid on
xlabel('sigmf, P=[2 4]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,3,2)
y = dsigmf(x,[5 2 5 7]);
plot(x,y,'linewidth',2), grid on
xlabel('dsigmf, P=[5 2 5 7]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,3,3)
y = psigmf(x,[2 3 -5 8]);
plot(x,y,'linewidth',2), grid on
xlabel('psigmf, P=[2 3 -5 8]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);

subplot(1,3,1)
x = 0:0.1:10;
y = zmf(x,[3 7]);
plot(x,y,'linewidth',2), grid on
xlabel('zmf, P=[3 7]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,3,2)
y = pimf(x,[1 4 5 10]);
plot(x,y,'linewidth',2), grid on
xlabel('pimf, P=[1 4 5 10]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);
subplot(1,3,3)
y = smf(x,[1 8]);
plot(x,y,'linewidth',2), grid on
xlabel('smf, P=[1 8]')
ylim([-0.05 1.05])
set(gca,'YTick',0:0.25:1);

