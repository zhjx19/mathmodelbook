%% 模糊综合评价步骤
A = [0.3 0.3 0.3 0.1]';
R = [0.8 0.7 0.6 0.7;
     0.1 0.2 0.2 0.1;
     0.1 0.1 0.2 0.2];    
fce(A,R,1)

%% 模糊综合评价实例
% 粮食亩产量对评语"差"的隶属函数
x = 0:800;
mf11 = @(x) trapmf(x,[0,0,350,450]);    % 右梯形  
subplot(2,2,1)
plot(x,mf11(x),'linewidth',2)
xlabel('差')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1);

% 粮食亩产量对评语"中"的隶属函数
mf12 = @(x) trapmf(x,[250,350,450,550]);
subplot(2,2,2)
plot(x,mf12(x),'linewidth',2)
xlabel('中')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1);

% 粮食亩产量对评语"良"的隶属函数
mf13 = @(x) trapmf(x,[350,450,550,650]);
subplot(2,2,3)
plot(x,mf13(x),'linewidth',2)
xlabel('良')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1);

% 粮食亩产量对评语"优"的隶属函数          
mf14 = @(x) trapmf(x,[450,550,800,800]);   % 左梯形
subplot(2,2,4)
plot(x,mf14(x),'linewidth',2)
xlabel('优')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1);

% 农产品质量对评语"差"的隶属函数
x = 0:0.01:5; 
mf21 = @(x) trapmf(x,[3.5,4,5,5]); 
figure
subplot(2,2,1)
plot(x,mf21(x),'linewidth',2)
xlabel('差')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1, 'XTick',0:5);

% 农产品质量对评语"中"的隶属函数
mf22 = @(x) trimf(x,[2.5,3,3.5]);
subplot(2,2,2)
plot(x,mf22(x),'linewidth',2)
ylim([-0.05 1.05]), grid on
xlabel('中')
set(gca,'YTick',0:0.25:1, 'XTick',0:5);

% 农产品质量对评语"良"的隶属函数
mf23 = @(x) trimf(x,[1.5,2,2.5]);
subplot(2,2,3)
plot(x,mf23(x),'linewidth',2)
xlabel('良')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1, 'XTick',0:5);

% 农产品质量对评语"优"的隶属函数
mf24 = @(x) trapmf(x,[0 0 1 1.5]);
subplot(2,2,4)
plot(x,mf24(x),'linewidth',2)
xlabel('优')
ylim([-0.05 1.05]), grid on
set(gca,'YTick',0:0.25:1, 'XTick',0:5);

mf31 = @(x) trapmf(x,[40 60 80 80]);
mf32 = @(x) trapmf(x,[20 40 60 80]);
mf33 = @(x) trapmf(x, [0 20 40 60]);
mf34 = @(x) trapmf(x,[0 0 20,40]);
mf41 = @(x) trapmf(x, [0 0 50 90]);
mf42 = @(x) trapmf(x, [0 50 90 130]);
mf43 = @(x) trapmf(x, [50 90 130 170]);
mf44 = @(x) trapmf(x, [90 130 170 170]);
mf51 = @(x) trapmf(x, [3.5 4 5 5]);
mf52 = @(x) trimf(x, [2.5 3 3.5]);
mf53 = @(x) trimf(x, [1.5 2 2.5]);
mf54 = @(x) trapmf(x, [0 0 1 1.5]);

CalFEM = @(x) [
    mf11(x(1)), mf21(x(2)), mf31(x(3)), mf41(x(4)), mf51(x(5));
    mf12(x(1)), mf22(x(2)), mf32(x(3)), mf42(x(4)), mf52(x(5));
    mf13(x(1)), mf23(x(2)), mf33(x(3)), mf43(x(4)), mf53(x(5));
    mf14(x(1)), mf24(x(2)), mf34(x(3)), mf44(x(4)), mf54(x(5))]; 

x = [592.5 3 55 72 4;
     529 2 38 105 3;
     412 1 32 85 2];

R1 = CalFEM(x(1,:))
R2 = CalFEM(x(2,:))
R3 = CalFEM(x(3,:))

A = [0.2 0.1 0.15 0.3 0.25]';
type = 3;                          % 选择加权平均型
B1 = fce(A, R1, type)
B2 = fce(A, R2, type)
B3 = fce(A, R3, type)

w = [30 60 75 90];
s1 = w * B1
s2 = w * B2
s3 = w * B3