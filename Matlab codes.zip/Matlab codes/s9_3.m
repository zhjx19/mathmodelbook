clc
clear
%% 灰色关联分析
dat = xlsread('datas/sport_datas.xlsx');
% 预处理数据
for i=2:16
    dat(:,i) = dat(:,i) / dat(1,i);
end
for i=17:18
    dat(:,i) = dat(1,i) ./ dat(:,i);
end
ck = dat(:,2);        % 参考序列
bj = dat(:,3:end);    % 比较序列
r = gray_corr(ck,bj,0.5)

%% 优势分析
dat = xlsread('datas/economy_datas.xlsx');
% 预处理数据
for i=2:12
    dat(:,i) = dat(:,i) / dat(1,i);
end
mu = dat(:,7:end);      % 母因素
zi = dat(:,2:6);        % 子因素
R = zeros(6,5);
for i=1:6     
    R(i,:) = gray_corr(mu(:,i), zi, 0.5);
end
R

