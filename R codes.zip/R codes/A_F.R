## 附录F 正态性变换

library(bestNormalize)

x = rgamma(100, 1, 1)
yj_obj = yeojohnson(x)
yj_obj$lambda            # 最优lambda


p = predict(yj_obj)      # 变换
x2 = predict(yj_obj, newdata = p, inverse = TRUE)
