## 居中型指标
MiddleType = function(x, m) {
  # 居中型数据转换, m为唯一的最优值
  d = abs(x - m)
  1 - d / max(d)
}

## 区间型指标
IntervalType = function(x, a, b) {
  # 区间型数据转换, [a,b]为最优区间
  M = max(a-min(x), max(x)-b)
  y = rep(1, length(x))
  y[x<a] = 1 - (a-x[x<a]) / M
  y[x>b] = 1 - (x[x>b]-b) / M
  y
}

## 归一化
rescale = function(x, type = "pos", a = 0, b = 1) {
  rng = range(x, na.rm = TRUE)
  switch(type,
         "pos" = (b - a) * (x - rng[1]) / (rng[2] - rng[1]) + a,
         "neg" = (b - a) * (rng[2] - x) / (rng[2] - rng[1]) + a)
}