PCA_Weight = function(pc) {
  # 输入参数pc为psych包的主成分分析函数principal()的返回结果
  # 返回结果为PCA权重及中间结果
  A = matrix(pc$loadings, ncol = pc$factors)
  lambda = pc$values[1:ncol(A)]
  B = A / sqrt(matrix(rep(lambda, times = nrow(A)), ncol = ncol(A), byrow = TRUE))
  varP = pc$Vaccounted[2,]
  beta = abs(B %*% varP) / sum(varP)
  w = beta / sum(beta)
  list(lambda = lambda, B = B, beta = beta[,1], w = w[,1])
}