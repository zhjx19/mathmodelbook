## 灰色关联度
gray_corr = function(ck, bj, rho = 0.5, w = NULL) {
  # 计算灰色关联度
  # ck为参考序列, bj为比较序列, rho为分辨系数
  # w为加权关联度的权重向量
  n = nrow(bj)
  if(is.null(w)) w = rep(1/n, n)
  t = apply(bj, 2, \(x) x - ck)
  min2 = min(apply(abs(t), 2, min))       # 求两级最小差
  max2 = max(apply(abs(t), 2, max))       # 求两级最大差
  eta = (min2 + rho*max2) / (abs(t) + rho*max2)  # 求关联系数
  r = w %*% eta
  r[1,]
}

## 灰色关联评价
gray_corr_eval = function(A, w, rho = 0.5) {
  # 实现用灰色关联评价
  # A为决策矩阵, w为各指标的权重向量
  # rho为灰色关联的分辨系数
  B = apply(A, 2, \(x) x / norm(x, "2"))   # 规范化处理
  C = apply(B, 1, \(x) w * x) |> t()       # 加权规范矩阵
  ck = apply(C, 2, max)
  f = gray_corr(ck, t(C), rho)
  100 * f / sum(f)                         # 归一化到[0,100]
}
