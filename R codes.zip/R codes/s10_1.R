## 10.1 线性回归

library(tidyverse)

df = read_csv("datas/Salary_Data.csv")
df

df %>% 
  ggplot(aes(Year, Salary)) +
  geom_point()

m = lm(Salary ~ Year, df)
df1 = df[24,] %>% 
  mutate(p = predict(m, .))

ggplot(df, aes(Year, Salary)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  geom_segment(aes(x = Year, y = Salary, xend = Year, yend = p),
               data = df1, linetype = 3, color = "red", size = 1.1)

## 正规方程法
x = df$Year
X = cbind(rep(1,length(x)), x)
y = df$Salary
theta = MASS::ginv(X) %*% y

## 例10.1
df = readxl::read_xlsx("datas/Predict_Profit.xlsx")
summary(df)
R = cor(df[, c(1:3,5)])
R

# 共线性诊断
mdl0 = lm(Profit ~ ., df)
car::vif(mdl0)
mctest::imcdiag(mdl0)

# 多元线性回归
mdl0 = lm(Profit ~ ., df)
# 逐步回归
mdl1 = step(mdl0, direction = "backward",
            trace = 0)        # 避免输出中间过程
summary(mdl1)

# 处理虚拟变量
count(df, State) %>% 
  mutate(prop = n / sum(n))

library(modelr)
model_matrix(df, ~ State - 1)
model_matrix(df, ~ State)

summary(mdl0)

# 提取回归模型结果
library(broom)
tidy(mdl0)
glance(mdl0)
augment(mdl0)

# 回归诊断
library(ggfortify)
autoplot(mdl0, which = c(1:3,6))   # 6 个图形可选

shapiro.test(mdl0$residuals)       # 残差正态性检验
library(lmtest)
dwtest(mdl0)                       # 残差独立性检验
bptest(mdl0)                       # 残差异方差检验

# Cook's距离
CooksD = cooks.distance(mdl0)
CooksD[CooksD > 3 * mean(CooksD)]
# 高杠杆值
HLs = hatvalues(mdl0)
HLs[HLs > 2*6/49]

# Bonferroni异常值检验
car::outlierTest(mdl0)

# 模型预测
newdat = tibble(
  RD_Spend = c(15, 8),
  Administration = c(10, 15),
  Marketing_Spend = c(20, 40),
  State = c("New York", "Florida"))

predict(mdl0, newdat)

