## 10.2 线性回归进阶

library(tidyverse)

## 梯度下降法
gd = function(X, y, init, eta = 1e-3, err = 1e-3, maxit = 1000, adapt = FALSE) {
  ## X 为自变量数据矩阵, y 为因变量向量, init 为参数初始值, eta 为学习率
  ## err 为误差限, maxit 为最大迭代次数, adapt 是否自适应修改学习率
  ## 返回回归系数估计, 损失向量, 迭代次数, 拟合值, RMSE
  # 初始化
  X = cbind(Intercept = 1, X)
  beta = init
  names(beta) = colnames(X)
  loss = crossprod(X %*% beta - y)
  tol = 1
  iter = 1
  # 迭代
  while(tol > err && iter < maxit) {
    LP = X %*% beta
    grad = t(X) %*% (LP - y)
    betaC = beta - eta * grad
    tol = max(abs(betaC - beta))
    beta = betaC
    loss = append(loss, crossprod(LP - y))
    iter = iter + 1
    if(adapt)
      eta = ifelse(loss[iter] < loss[iter-1], eta * 1.2, eta * 0.8)
  }
  list(beta = beta, loss = loss, iter = iter, fitted = LP,
       RMSE = sqrt(crossprod(LP - y) / (nrow(X) - ncol(X))))
}

set.seed(123)
x1 = rnorm(1000)
x2 = rnorm(1000)
y = 1 + 0.6*x1 - 0.5*x2 + rnorm(n)

X = cbind(x1, x2)
gd_rlt = gd(X, y, rep(0,3), err = 1e-8, eta = 1e-4, adapt = TRUE)
rbind(gd = round(gd_rlt$beta[, 1], 5),
      lm = coef(lm(y ~ x1 + x2)))   # 与lm 结果对比

## 非线性拟合
library(gslnls)

## 例10.2
set.seed(123)

df = tibble(
  x = c(2,3,4,5,7,9,12,14,17,21,28,56), 
  y= c(35,42,47,53,59,65,68,73,76,82,86,99) + rnorm(12) - 0.5
)

s = rnorm(4)

rlt = gsl_nls(y ~ a + k1 * exp(m * x) + k2 * exp(-m * x), df, 
              start = list(a = s[1], m = s[2], k1 = s[3], k2 = s[4]))
rlt
summary(rlt)

# 预测值
df %>% 
  mutate(yhat = predict(rlt, .))

cf = coef(rlt)
f = function(x) cf[1] + cf[3] * exp(cf[2] * x) + cf[4] * exp(-cf[2] * x)

df %>% 
  ggplot(aes(x, y)) +
  geom_point(color = "red") +
  geom_function(fun = f, color = "blue")

## 插值拟合
library(pracma)

## 例10.3
# 线性插值
f1 = ppfit(df$x, df$y, df$x)
plot(df$x, df$y, col = "red")
x = seq(0,60,0.1)
lines(x, ppval(f1, x), col = "blue")
grid(6,7)

# 三次多项式(样条)插值
f2 = ppfit(df$x, df$y, df$x, method = "cubic")
plot(df$x, df$y, col = "red")
x = seq(0,60,0.1)
lines(x, ppval(f2, x), col = "blue")
grid(6,7)

# interp1()   # "nearest"

## 例10.4 一元多项式拟合
df = tibble(
  Year = 1995:2014,
  Population = c(121121,122389,123626,124761,125786,126743,127627,128453,
                 129227,129988,130756,131448,132129,132802,133450,134091,
                 134735,135404,136072,136782))

p = df %>% 
  ggplot(aes(Year, Population)) +
  geom_point(color = "red")
p

mdl = lm(Population ~ poly(Year, 2, raw = TRUE), df)
summary(mdl)

# 预测值
df %>% 
  mutate(Pophat = predict(mdl, .))

f = function(x) coef(mdl)[1] + coef(mdl)[2] * x + coef(mdl)[3] * x^2
p +
  geom_function(fun = f, color = "blue")

## 多元多项式回归
df = readxl::read_xlsx("datas/Predict_Profit.xlsx")
df1 = df[,-c(2,4)]

mdl2 = lm(Profit ~ polym(RD_Spend, Marketing_Spend, degree=2, raw=TRUE), df1)
summary(mdl2)

## 逐步回归
mdl3 = lm(Profit ~ ., df) %>% 
  step(direction = "backward")

summary(mdl3)

