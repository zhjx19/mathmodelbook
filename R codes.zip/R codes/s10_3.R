## 10.3 广义线性模型

library(tidyverse)

## Logistic回归
df = read.table("datas/FearfulAngry.txt", sep = ",") %>% 
  set_names("x", "y")

df %>% 
  ggplot(aes(x, y)) +
  geom_point() +
  geom_smooth(method = "lm")

sigmoid = function(x) 1 / (1 + exp(-x))

ggplot() +
  geom_function(fun = sigmoid, color = "blue") +
  xlim(-10, 10) +
  geom_hline(yintercept = 0:1, linetype = 2, color = "red")

log_reg = glm(y ~ x, df, family = "binomial")
summary(log_reg)

yhat = predict(log_reg, df, type = "response")

bind_cols(df, yhat) %>% 
  ggplot(aes(x, y)) +
  geom_point() +
  geom_line(aes(x, yhat), color = "red")

yh = ifelse(yhat > 0.5, 1, 0)
mean(df$y == yh)

## 泊松回归
df = read_csv("datas/ViolentCrimes.csv")

df %>% 
  ggplot(aes(nv, y = ..density..)) +
  geom_histogram(bins = 20, fill = "steelblue", 
                 color = "black") +
  geom_density(color = "red")

df = df %>% 
  mutate(log_enroll = log(enroll1000))

pos_log = glm(nv ~ type + region, df, family = "poisson",
              offset = log_enroll)
summary(pos_log)

