## 10.4 灰色预测

GM11 = function(x) {
# 实现GM(1,1)算法，输入原始序列数据
# 返回第n+1个预测值pre，预测函数f,级比lamda,可容覆盖范围range,相对残差phi,级比偏差rho
# 级比检验
  n = length(x)
  lambda = x[1:n-1] / x[2:n]              # 计算级比
  rng = c(exp(-2/(n+1)), exp(2/(n+2)))    # 可容覆盖的范围
  if(rng[1] < min(lambda) & max(lambda) < rng[2]) {
    print("级比检验通过!") } else {
      print("级比检验未通过!")
    }
  # GM(1,1)建模
  x1 = cumsum(x)                          # 一次累加
  n = length(x1)
  z1 = (x1[1:n-1] + x1[2:n]) / 2
  Y = x[2:n]                              # 构造矩阵Y
  B = cbind(-z1, rep(1,n-1))              # 构造矩阵B
  A = MASS::ginv(B) %*% as.matrix(Y)      # 计算模型的参数a,b
  k = 1:n 
  # 利用模型计算累加值的预测值
  x1 = (x[1]-A[2]/A[1])*exp(-A[1]*(k-1))+A[2] / A[1]  
  x_p=c(x[1], diff(x1))                   # 累减还原到预测值
  Delta = abs(x_p-x)                      # 绝对残差序列
  phi = Delta / x                         # 相对残差序列
  if(max(phi) >= 0.2) {
      print("相对残差检验未通过!")
  } else {
      print("相对残差检验通过")
  }
  rho = 1-(1-0.5*A[1])/(1+0.5*A[1])*lambda   # 计算级比偏差值
  if(max(rho) >= 0.2) {
    print("级比偏差检验未通过!")
  } else {
    print("级比偏差检验通过!")
  }
  f = function(t) (x[1]-A[2]/A[1])*(1-exp(A[1]))*exp(-A[1]*t)  # 预测公式
  pre = f(n)
  list(pre = pre, f = f, lambda = lambda, rng = rng, phi = phi, rho = rho)  
}

library(tidyverse)
library(lubridate)

tour = readxl::read_xlsx("datas/北京市接待海外旅游人数.xlsx") 

tour1 = tour %>% 
  filter(年份 != 2003)

tour_long = tour1 %>% 
  pivot_longer(-1, names_to = "Month", values_to = "n") %>% 
  mutate(Date = make_date(年份, parse_number(Month), 15))

tour_long %>% 
  ggplot(aes(Date, n)) +
  geom_line(color = "blue") +
  scale_x_date()

tour_sum = tour_long %>% 
  group_by(年份) %>% 
  summarise(n = mean(n))

tour_sum

tour_sum %>% 
  ggplot(aes(年份, n)) +
  geom_line(color = "blue")

# 用GM11预测
perMon = tour_sum$n
rlt = GM11(perMon)
rlt

w = apply(tour1[,-1], 2, sum) / sum(tour1[,-1])
pre03 = rlt$pre * 12 * w

# 用数据融合改进预测
DataFusion = function(x) {
  # x为长度≥2的行向量, 返回a为融合值, w为权重向量
  Lx = length(x)
  if(Lx == 2) {
    a = mean(x)
    w = c(1/2,1/2)
  }
  IndCom = combn(1:Lx,2)      # x中元素下标索引的所有两两组合方式
  d = abs(x[IndCom[1,]] - x[IndCom[2,]])  # 计算任意两值之间的距离
  maxd = max(d)
  idx = expand.grid(1:Lx,1:Lx)
  # 构造支持度矩阵
  R = matrix(cos(pi*(x[idx[,1]]-x[idx[,2]]) / (2*maxd)), 
             nrow = Lx, byrow = TRUE)
  rlt = eigen(R)
  w = rlt$vectors[,1] / sum(rlt$vectors[,1])
  a = sum(x * w)
  list(a = a, w = w)
}

n = length(perMon)
pres = map_dbl(1:ceiling(n/2), ~ GM11(perMon[.x:n])$pre)

pre2 = DataFusion(pres)$a    # 融合预测值
pre03f = pre2 * 12 * w                                 

rlts = tibble(
  月份 = 1:12,
  真实值 = unlist(tour[7,2:13]),
  预测值 = pre03,
  融合预测值 = pre03f
) 
rlts

rlts %>% 
  pivot_longer(-1, names_to = "类别", values_to = "人数") %>% 
  ggplot(aes(月份, 人数, color = 类别)) +
  geom_line(size = 1.1)
