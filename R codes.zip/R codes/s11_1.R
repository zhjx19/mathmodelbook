## 11.1 预备知识

df = readxl::read_xlsx("datas/export_datas.xlsx")
head(df)

## 创建时间序列
x = ts(df$export, start = c(2001,10), frequency = 12)
plot(x, xlab = "时间", ylab = "出口额(亿美元)")    # 时序图

## 平稳化处理
xs = diff(log(x))   # 先取对数再做 1 阶差分
plot(xs, xlab = "时间", ylab = "diff(log(出口额))")  

library(fUnitRoots)
adfTest(xs)                            # ADF检验

