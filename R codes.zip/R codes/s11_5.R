## 11.5 GARCH模型

df = read.table("datas/m-intcsp7309.txt", header = TRUE)
head(df)

intc = log(df$intc + 1)         # 对数收益率
rtn = ts(intc, frequency = 12, start = c(1973,1))   # 转化为时间序列
plot(rtn, xlab = "year", ylab = "ln-rtn")           #绘制时序图


## ARCH效应检验

archTest = function(x, m = 10) {
  # 拉格朗日乘数法检验ARCH效应
  # x为中心化的时间序列
  # m为检验的自回归阶数
  y = (x - mean(x))^2
  T = length(x)
  atsq = y[(m+1):T]
  xmat = matrix(0, T-m, m)
  for (j in 1:m) {
    xmat[,j] = y[(m+1-j):(T-j)]
  }
  lmres = lm(atsq ~ xmat)
  summary(lmres)
}

y = rtn - mean(rtn)
archTest(y, 12)


## GARCH建模

library(fGarch)

mdl = garchFit(~ garch(1,1), data = intc, trace = FALSE)
summary(mdl)


## 可视化
plot(mdl, which = 2)  # 条件
plot(mdl, which = 3)  # 原序列叠加2倍条件SD
plot(mdl, which = 6)  # 交叉相关系数
plot(mdl, which = 7)  # 残差图
plot(mdl, which = 8)  # 条件SD'
plot(mdl, which = 9)  # 标准化残差图
plot(mdl, which = 10) # 标准化残差的ACF图
plot(mdl, which = 11) # 标准化残差平方的ACF图
plot(mdl, which = 12) # 交叉相关系数
plot(mdl, which = 13) # Q-Q图


## 提取波动率
volatility(mdl, type = "sigma")   # 条件标准差
volatility(mdl, type = "h")       # 条件方差

## 预测
predict(mdl, n.ahead = 10, mse = "cond", plot = TRUE)
predict(mdl, n.ahead = 10, mse = "uncond", plot = TRUE)
