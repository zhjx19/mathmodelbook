### 1.3 初等模型

## 求解非线性符号方程组
# 说明: R在符号方程方面基本就是残废
# 若需要求解符号方程, 建议用Mathematica
# 该简单方程组, 间接用Python的sympy库求解

library(reticulate)
use_python(Sys.which("python"))

library(caracas)

Q2 = symbol("Q2")
Kg = symbol("Kg")
Ka = symbol("Ka")
T1 = symbol("T1")
T2 = symbol("T2")
Ta = symbol("Ta")
Tb = symbol("Tb")
d = symbol("d")
el = symbol("el")

lhs = cbind(Q2, Q2, Q2)
rhs = cbind(Kg * (T1-Ta) / d, Ka * (Ta-Tb) / el, Kg * (Tb - T2) / d)

solve_sys(lhs, rhs, list(Q2, Ta, Tb))



## 定义函数
f = function(h) 1 / (1 + 8 * h)

h = 1:5
1 - f(h)


## 可视化
h = seq(0, 8, 0.01)
r = f(h)
plot(h, r, type = "l", col = "red",
     xlab = "h (l/d)", ylab = "Q1/Q2",
     main = "热量损失比Q1/Q2与h的关系")       
grid(8, 10)     # 添加网格线

## 停止准则
n = length(r)
dh = 0.01
df = (r[2:n] - r[1:(n-1)]) / dh
n = sum(abs(df) > 0.01)
h[n]
f(h[n])


## 肘法
ElbowPoint = function(x, y) {
  n = length(x)
  points = cbind(x, y)
  
  firstP = points[1,]                  # 取出第1个点
  lineVec = points[n,] - firstP        # 第1个点与最后一个点的向量
  lineVecN = lineVec / sqrt(sum(lineVec ^ 2))   # 归一化
  
  vecFromFirst = sweep(points, 2, firstP)  # 所有点减去第一个点
  
  # 将vecFromFirst中每个向量分解为两个分量，一个分量与直线平行
  # 另一个分量与直线垂直，然后取与直线垂直的部分的范数则得到距离
  scalarProduct = matrix(0, n, 1)
  for(i in 1:n) {
    scalarProduct[i,1] = crossprod(vecFromFirst[i,], lineVecN)  
  }
  
  vecProj = scalarProduct %*% lineVecN      # 投影向量
  vecToLine = vecFromFirst - vecProj        # 垂直向量
  
  # 到直线的距离是vecToLine的范数
  distToLine = sqrt(apply(vecToLine ^ 2, 1, sum))
  idx = which.max(distToLine) 
  
  list(x = x[idx], y = y[idx])
}

h = seq(0.2, 8, 0.01)
r = f(h)
ElbowPoint(h, r)

