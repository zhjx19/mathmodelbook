### 2.2 层次分析法, 选择最佳旅游地

A = matrix(c(1,   1/2, 4, 3,   3,
             2,   1,   7, 5,   5,
             1/4, 1/7, 1, 1/2, 1/3,
             1/3, 1/5, 2, 1,   1,
             1/3, 1/5, 3, 1,   1), byrow = TRUE, nrow = 5)
A

## 方根法, 近似计算最大特征值及其对应的特征向量
W = apply(A, 1, prod)   # 计算每一行乘积
W

n = length(W)
W = W^(1/n)
W

W = W / sum(W)
W

Lmax = mean(A %*% W / W)
Lmax

CI = (Lmax - n) / (n - 1)
CI

RI = c(0,0,0.58,0.90,1.12,1.24,1.32,1.41,1.45,1.49,1.51)
CR = CI / RI[n]
CR

## 改造成函数, 近似法AHP

aAHP = function(A) {
  ## 实现单位根近似的层次分析法
  # 输入: A 为判断矩阵
  # 输出: 权重向量, 一致性比率, 最大特征值, 一致性指标
  
  W = apply(A, 1, prod)      # 计算每一行的乘积
  n = nrow(A)
  W = W ^ (1/n)              # 计算n次方根
  W = W / sum(W)             # 归一化处理得权重向量
  Lmax = mean(A %*% W / W)   # 计算最大特征值
  CI = (Lmax - n) / (n - 1)  # 一致性指标
  
  # Saaty随机一致性指标值
  RI = c(0,0,0.58,0.90,1.12,1.24,1.32,1.41,1.45,1.49,1.51)
  CR = CI / RI[n]            # 计算一致性比率
  list(W=W, CR=CR, Lmax=Lmax, CI=CI)
}

L1 = aAHP(A)
L1

## 精确法AHP

AHP = function(A) {
  ## 实现层次分析法
  # 输入: A 为判断矩阵
  # 输出: 权重向量, 一致性比率, 最大特征值, 一致性指标
  
  rlt = eigen(A)
  Lmax = Re(rlt$values[1])  # 最大特征值
  W = Re(rlt$vectors[,1]) / sum(Re(rlt$vectors[,1]))  # 权重向量
  n = nrow(A)
  CI = (Lmax - n) / (n - 1)           # 一致性指标
  # Saaty随机一致性指标值
  RI = c(0,0,0.58,0.90,1.12,1.24,1.32,1.41,1.45,1.49,1.51)
  CR = CI / RI[n]
  list(W=W, CR=CR, Lmax=Lmax, CI=CI)  # 计算一致性比率
}

A = matrix(c(1,   1/2, 4, 3,   3,
             2,   1,   7, 5,   5,
             1/4, 1/7, 1, 1/2, 1/3,
             1/3, 1/5, 2, 1,   1,
             1/3, 1/5, 3, 1,   1), byrow = TRUE, nrow = 5)

AHP(A)


## 第二级层次结构

B1 = matrix(c(1,  2, 5,
              1/2,1, 2,
              1/5,1/2,1), nrow = 3, byrow = TRUE)
B2 = matrix(c(1, 1/3, 1/8,
              3, 1, 1/3,
              8, 3, 1), nrow = 3, byrow = TRUE)
B3 = matrix(c(1, 1, 3,
              1, 1, 3,
              1/3,1/3,1), nrow = 3, byrow = TRUE) 
B4 = matrix(c(1, 3, 4,
              1/3,1, 1,
              1/4,1, 1), nrow = 3, byrow = TRUE)
B5 = matrix(c(1, 1, 1/4,
              1, 1, 1/4,
              4, 4, 1), nrow = 3, byrow = TRUE)

# 依次对5个矩阵作用上aAHP函数, 得到所有结果
rlt = list(B1,B2,B3,B4,B5) %>% 
  map(aAHP)

# 批量提取并合并结果
L2 = rbind(
  map_dfc(rlt, "W"),
  map_dbl(rlt, "Lmax"),
  map_dbl(rlt, "CI"),
  map_dbl(rlt, "CR"))
L2

# 向上加权合成得到目标权重
as.matrix(L2[1:3,]) %*% L1$W
