library(tidyverse)
library(deSolve)

# 说明: R在求微分方程解析解方面, 基本就是残废
# 若需要求解析解, 建议用Mathematica
# 本章直接求微分方程数值解

## 3.1 Malthus人口模型

Malthus = function(t, y, parms) {
  # 从向量y中取出状态变量
  P = y[1]
  # 从参数向量parms取出参数值
  r = parms["r"]
  # 定义方程组
  dP = r * P
  # 返回梯度列表
  list(dP)
}

times = 0:1000
parms = c(r = 0.01)
start = c(P = 1e8)

out = ode(y=start, times=times, func=Malthus, parms=parms) 

out %>% 
  data.frame() %>% 
  ggplot(aes(time, P)) +
  geom_line()

# 美国1790-1930年人口数据(10年为间隔)
df = tibble(
  year = seq(1790, 1930, by = 10),
  P = c(3.9, 5.3, 7.2, 9.6, 12.9, 17.1, 23.2, 31.4, 
        38.6, 50.2, 62.9, 76.0, 92.0, 106.5, 123.2))

ggplot(df, aes(year, P)) +
  geom_point(color = "blue")

ggplot(df, aes(year, log(P))) +
  geom_point(color = "blue")


df = df %>% 
  mutate(X = year - 1789, y = log(P))
mdl = lm(y ~ X, df)
summary(mdl)

# 定义预测函数
df = df %>% 
  mutate(Pred = exp(predict(mdl, .["X"])),
         Error = 100 * abs(P - Pred) / P)
df

df %>% 
  pivot_longer(c(2,5), names_to = "类别", values_to = "val") %>% 
  mutate(类别 = factor(类别, labels = c("真实值", "预测值"))) %>% 
  ggplot(aes(year, val, color = 类别)) +
  geom_point() +
  labs(x = "年份", y = "人口数（百万）")




