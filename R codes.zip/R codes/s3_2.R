library(tidyverse)
library(deSolve)

## 3.2 Logistic人口模型

Logistic = function(t, y, parms) {
  # 从向量y中取出状态变量
  N = y[1]
  # 从参数向量parms取出参数值
  r = parms["r"]
  K = parms["K"]
  # 定义方程组
  dN = r * (1 - N / K) * N
  # 返回梯度列表
  list(dN)
}

times = seq(0, 20, by = 0.01)
parms = c(r = 0.9, K = 100)
start = c(N = 150)
out1 = ode(y=start, times=times, func=Logistic, parms=parms) 

start = c(N = 20)
out2 = ode(y=start, times=times, func=Logistic, parms=parms) 

df = bind_rows(data.frame(out1), data.frame(out2), .id = "初始人口") %>% 
  mutate(初始人口 = factor(初始人口, labels = c("N0=150", "N0=20"))) 
df

df %>% 
  ggplot(aes(time, N, color = 初始人口)) +
  geom_line(size = 1.2) +
  geom_hline(yintercept = 100, linetype = "dotted") +
  labs(x = "t", y = "N(t)")

df = df %>% 
  filter(初始人口 == "N0=20") %>% 
  mutate(dN = parms["r"] * (1 - N / parms["K"]) * N) 

df %>% 
  ggplot(aes(time, dN)) +
  geom_line(color = "steelblue", size = 1.2)

df %>% 
  slice_max(dN, n = 1)

# 电影票房预测

df = readxl::read_xlsx("datas/历年累计票房.xlsx") %>%
  mutate(年份 = 年份 - 2002)

p = ggplot(df, aes(年份, 累计票房)) +
  geom_point(color = "red", size = 1.5)
p

lm.fit = lm(car::logit(累计票房/ 800) ~ 年份, df)
coef(lm.fit)

log.fit = nls(累计票房~ phi1 / (1 + exp(-(phi2 + phi3 * 年份))),
                  data = df,
                  start = list(phi1 = 800, phi2 = -5.14, phi3 = 0.39))
coefs = coef(log.fit)
coefs

LogFit = function(x) coefs[1] / (1 + exp(-(coefs[2] + coefs[3] * x)))
p + 
  geom_function(fun = LogFit, color = "steelblue", size = 1.2)
