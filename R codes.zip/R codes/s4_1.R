## 4.1 SI/SIS模型

library(tidyverse)
library(deSolve)

## SI模型

SI = function(t, y, parms) {
  # 从向量y中取出状态变量
  I = y[1]
  # 从参数向量parms取出参数值
  lambda = parms["lambda"]
  # 定义方程组
  dI = lambda * (1 - I) * I
  # 返回梯度列表
  list(dI)
}

times = seq(0, 2, by = 0.01)
parms = c(lambda = 5)
start = c(I = 0.1)
simSI = ode(y=start, times=times, func=SI, parms=parms) %>% 
  data.frame() 

simSI %>% 
  ggplot(aes(time, I)) +
  geom_line(size = 1.2, color = "red") +
  geom_hline(yintercept = 1, linetype = "dotted", 
             size = 1.2, color = "blue") +
  labs(x = "时间", y = "感染比例")

simSI = simSI %>% 
  mutate(dI = 5 * (1-I) * I) 

simSI %>% 
  slice_max(dI)

simSI %>% 
  ggplot(aes(time, dI)) +
  geom_line(size = 1.2, color = "red") +
  geom_point(data = slice_max(simSI, dI), aes(time, dI), 
             size = 4, color = "blue")

## SIS模型

SIS = function(t, y, parms) {
  # 从向量y中取出状态变量
  I = y[1]
  # 从参数向量parms取出参数值
  lambda = parms["lambda"]
  sigma = parms["sigma"]
  K = 1 - 1 / sigma
  # 定义方程组
  dI = lambda * (K - I) * I
  # 返回梯度列表
  list(dI)
}

# lambda = 5, sigma = 5, I0 = 0.1
times = seq(0, 2, by = 0.01)
parms = c(lambda = 5, sigma = 5)
start = c(I = 0.1)
simSIS = ode(y=start, times=times, func=SIS, parms=parms) %>% 
  data.frame() 

simSIS %>% 
  ggplot(aes(time, I)) +
  geom_line(size = 1.2, color = "red") +
  geom_hline(yintercept = c(0.8,1), linetype = "dotted", 
             size = 1.2, color = "blue") +
  labs(x = "时间", y = "感染比例") +
  scale_y_continuous(breaks = seq(0, 1, by = 0.2))

K = 1 - 1 / parms["sigma"]
simSIS = simSIS %>% 
  mutate(dI = 5 * (K - I) * I) 

simSIS %>% 
  slice_max(dI)

simSIS %>% 
  ggplot(aes(time, dI)) +
  geom_line(size = 1.2, color = "red") +
  geom_point(data = slice_max(simSIS, dI), aes(time, dI), 
             size = 4, color = "blue")

# lambda = 5, sigma = 0.8, I0 = 0.5
times = seq(0, 2, by = 0.01)
parms = c(lambda = 5, sigma = 0.8)
start = c(I = 0.5)
simSIS2 = ode(y=start, times=times, func=SIS, parms=parms) %>% 
  data.frame() 

simSIS2 %>% 
  ggplot(aes(time, I)) +
  geom_line(size = 1.2, color = "red") +
  geom_hline(yintercept = 1, linetype = "dotted", 
             size = 1.2, color = "blue") +
  labs(x = "时间", y = "感染比例") +
  scale_y_continuous(breaks = seq(0, 1, by = 0.2))

K = 1 - 1 / parms["sigma"]
simSIS2 = simSIS2 %>% 
  mutate(dI = 5 * (K - I) * I) 


