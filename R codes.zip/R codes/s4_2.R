## 4.2 SIR模型

library(tidyverse)
library(deSolve)

## SIR模型

SIR = function(t, y, parms) {
  # 从向量y中取出状态变量
  S = y[1]
  I = y[2]
  # 从参数向量parms取出参数值
  lambda = parms["lambda"]
  mu = parms["mu"]
  # 定义方程组
  dS = -lambda * S * I
  dI = lambda * S * I - mu * I
  # 返回梯度列表
  list(c(dS, dI))
}

# lambda = 0.6, mu = 0.3, S0 = 0.99, I0 = 0.01
times = seq(0, 50, by = 0.1)
parms = c(lambda = 0.6, mu = 0.3)
start = c(S = 0.99, I = 0.01)
simSIR = ode(y=start, times=times, func=SIR, parms=parms) %>% 
  data.frame() 

simSIR %>% 
  mutate(R = 1 - S - I) %>% 
  pivot_longer(2:4, names_to = "人群", values_to = "val") %>% 
  ggplot(aes(time, val, color = 人群)) +
  geom_line(size = 1.2) +
  labs(x = "时间", y = "人群占比") 

# lambda = 0.5, mu = 0.4, S0 = 0.99, I0 = 0.01
times = seq(0, 50, by = 0.1)
parms = c(lambda = 0.5, mu = 0.4)
start = c(S = 0.99, I = 0.01)
simSIR2 = ode(y=start, times=times, func=SIR, parms=parms) %>% 
  data.frame() 

simSIR2 %>% 
  mutate(R = 1 - S - I) %>% 
  pivot_longer(2:4, names_to = "人群", values_to = "val") %>% 
  ggplot(aes(time, val, color = 人群)) +
  geom_line(size = 1.2) +
  labs(x = "时间", y = "人群占比") 

simSIR %>% 
  ggplot(aes(S, I)) +
  geom_line(size = 1.2, color = "red")
