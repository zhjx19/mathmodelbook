## 4.3 舱室模型

library(tidyverse)
library(deSolve)

## SEIR模型

SEIR = function(t, y, parms) {
  # 从向量y中取出状态变量
  S = y[1]
  E = y[2]
  I = y[3]
  # 从参数向量parms取出参数值
  lambda = parms["lambda"]
  alpha = parms["alpha"]
  gamma = parms["gamma"]
  # 定义方程组
  dS = -lambda * I * S
  dE = lambda * I * S - alpha * E
  dI = alpha * E - gamma * I
  # 返回梯度列表
  list(c(dS, dE, dI))
}

# lambda = 0.6, alpha = 0.5, gamma = 0.3, S0 = 0.98, E0 = 0.01, I0 = 0.01
times = seq(0, 50, by = 0.1)
parms = c(lambda = 0.6, alpha = 0.5, gamma = 0.3)
start = c(S = 0.99, E = 0.01, I = 0.01)
simSEIR = ode(y=start, times=times, func=SEIR, parms=parms) %>% 
  data.frame() 
head(simSEIR)

simSEIR %>% 
  mutate(R = 1 - S - E - I) %>% 
  pivot_longer(2:5, names_to = "人群", values_to = "val") %>% 
  ggplot(aes(time, val, color = 人群)) +
  geom_line(size = 1.2) +
  labs(x = "时间", y = "人群占比") 
