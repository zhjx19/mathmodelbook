## 4.4 案例: SARS的传播规律

library(tidyverse)
library(deSolve)
library(lubridate)
library(patchwork)

## 准备数据与可视化探索
df = readxl::read_xlsx("datas/SARS_BJ.xlsx",
                       col_types = c("text", rep("numeric", 4)))

df = df %>% 
  transmute(日期 = ymd(str_c("2003年",日期)),
            days = (日期 - ymd("2003-04-20")) / ddays(1),
            R = 死亡累计 + 治愈出院累计,
            I = 已确诊病例累计 - R)
df

p1 = df %>% 
  ggplot(aes(days, I)) +
  geom_point(color = "blue") 

p2 = df %>% 
  ggplot(aes(days, R)) +
  geom_point(color = "blue")

p1 | p2

## 估计模型参数

df = df %>% 
  mutate(dR = R - lag(R), dI = I - lag(I),
         mu = dR / I, lambda = (dI + dR) / I)

p3 = df %>% 
  ggplot(aes(days, lambda)) +
  geom_point(color = "blue") +
  labs(y = "λ(t)")

p4 = df %>% 
  ggplot(aes(days, mu)) +
  geom_point(color = "blue") +
  labs(y = "μ(t)")

p3 | p4
  
## 探索并拟合λ(t)

df %>% 
  ggplot(aes(days, log(lambda))) +
  geom_point(color = "blue")

expfit1 = lm(log(lambda) ~ days, df[2:21,])
summary(expfit1)

fit1 = function(x) exp(coef(expfit1)[1] + coef(expfit1)[2] * x)

p3 +
  geom_function(fun = fit1, color = "red", size = 1.05)

## 探索并拟合μ(t)

expfit2 = lm(log(mu) ~ days, df[16:65,])
summary(expfit2)

fit2 = function(x) exp(coef(expfit2)[1] + coef(expfit2)[2] * x)

p4 +
  geom_function(fun = fit2, color = "red", size = 1.05)

## 求解TV-SIR模型

TVSIR = function(t, y, parms) {
  # 从向量y中取出状态变量
  I = y[1]
  R = y[2]
  # 从参数向量parms取出参数值
  a = parms["a"]
  b = parms["b"]
  c = parms["c"]
  d = parms["d"]
  # 定义方程组
  dI = (exp(a + b * t) - exp(c + d * t)) * I
  dR = exp(c + d * t) * I
  # 返回梯度列表
  list(c(dI, dR))
}

times = seq(0, 70, 0.1)
parms = c(a = -1.3425, b = -0.11433, c = -6.4784, d = 0.082829)
start = c(I = 288, R = 51)
simTVSIR = ode(y=start, times=times, func=TVSIR, parms=parms) %>% 
  data.frame() 

p5 = p1 +
  geom_line(data = simTVSIR, aes(x = time, y = I), color = "red") +
  theme(legend.position = "none")

p6 = p2 +
  geom_line(data = simTVSIR, aes(x = time, y = R, color = "red")) +
  theme(legend.position = "none")

p5 | p6
