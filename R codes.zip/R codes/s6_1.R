## 6.1 二次规划

library(CVXR)

## 决策变量
x = Variable(2)

## 目标函数
# 注意必须改写成二次优化标准形式(或等价形式), 否则无法识别为DCP问题
obj = 1/2 * (4 * x[1]^2 - 8 * x[1] * x[2] + 8 * x[2]^2) - 6 * x[1] - 3 * x[2]
# 或者
# H = matrix(c(4,-4,-4,8), nrow = 2)
# f = matrix(c(-6, -3), nrow = 1)
# obj = 1/2 * quad_form(x, H) + f %*% x

## 约束条件
constraints = list(
  x >= 0,
  x[1] + x[2] <= 3,
  4 * x[1] + x[2] <= 9)

## 创建优化问题并求解
problem = Problem(Minimize(obj), constraints)
result = solve(problem)

## 查看最优目标值和最优解
result$value
result$getValue(x)

