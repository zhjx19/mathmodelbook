## 6.2 多目标规划

# 多目标加权合成单目标, nloptr包


## 理想点法求解
library(pracma)

fn = function(x) norm(c(100*x[1]+90*x[2]+80*x[3]+70*x[4]-5960, 
                        3*x[2]+2*x[4]-30), "2")

A = matrix(c(-1,-1,0,0,
     0,0,-1,-1,
     3,0,2,0,
     0,3,0,2), nrow = 4, byrow = TRUE)
b = matrix(c(-30,-30,120,48), ncol = 1)

res = fmincon(rnorm(4), fn, A = A, b = b, lb = rep(0,4))
res$par
res$value

z1 = sum(c(100,90,80,70) * res$par)    # 目标1最优值
z2 = sum(c(0,3,0,2) * res$par)         # 目标2最优值

