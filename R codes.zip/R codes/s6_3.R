## 6.3 马科维茨均值-方差模型

library(tidyverse)
library(CVXR)

df = readxl::read_xlsx("datas/stock_datas.xlsx") 
df

df = df %>% 
  mutate(across(2:5, ~ .x - 1))
df

ER = apply(df[,2:4], 2, mean)
COV = cov(df[,2:4])
COR = cor(df[,2:4])

## 二次规划模型
w = Variable(3)

risk = quad_form(w, COV)

constraints = list(
  matrix(ER, nrow = 1) %*% w >= 0.15,
  sum(w) == 1,
  w >= 0
)

prob = Problem(Minimize(risk), constraints)
res = solve(prob)
res$value
res$getValue(w)

## 利用股票指数简化投资组合模型
lm1 = lm(股票A ~ 股票指数, df)   # a1, b1
lm2 = lm(股票B ~ 股票指数, df)   # a2, b2
lm3 = lm(股票C ~ 股票指数, df)   # a3, b3

mean(df$股票指数)    # m0
sd(df$股票指数)      # s0

summary(lm1)$sigma   # s1
summary(lm2)$sigma   # s2
summary(lm3)$sigma   # s3

## 双目标的帕累托寻优

lams = seq(0.01, 1, 0.01)
Returns = rep(0, 100)
Risks = rep(0, 100)

for(i in 1:100) {
  w = Variable(3)
  risk = quad_form(w, COV)
  ret = matrix(ER, nrow = 1) %*% w
  obj = lams[i] * risk - (1-lams[i]) * ret
  constraints = list(sum(w) == 1, w >= 0)
  prob = Problem(Minimize(obj), constraints)
  res = solve(prob)
  Returns[i] = res$getValue(ret)
  Risks[i] = res$getValue(risk)
}

tibble(收益 = Returns, 风险 = Risks) %>% 
  ggplot(aes(风险, 收益)) +
  geom_line(size = 1.2, color = "steelblue")
