clc
clear

%% ����װ��������
s = xlsread('results1_3.xlsx', 'sheet1', 'A1:L12');
y = xlsread('results1_3.xlsx', 'sheet1', 'A15:L15');
w = xlsread('results1_3.xlsx', 'sheet1', 'A18:L18');

[I,J] = find(s == 1);
rlts2 = table(I, J, y(J)', w(I)', ...
             'VariableNames', {'ID', '��', '����', 'w'})

grpstats(rlts2,'��','sum','DataVars','w')

rlts1 = readtable('results1_2.xlsx', 'VariableNamingRule', 'preserve');
rlts1 = rlts1(:, {'ID','��λ','ж��'});

rlts3 = join(rlts2, rlts1, 'Keys', 'ID')
