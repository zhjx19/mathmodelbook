## 8.1 数据指标预处理

library(tidyverse)

## 负向指标正向化
x[,j] = 1 / x[,j]                 # 倒数变换
x[,j] = max(x[,j]) - x[,j]        # 极小极大化变换

## 居中型指标
MiddleType = function(x, m) {
  # 居中型数据转换, m为唯一的最优值
  M = max(x - m)
  1 - abs(x - m) / M
}

PH = 6:9
MiddleType(PH, 7)

## 区间型指标
IntervalType = function(x, a, b) {
  # 区间型数据转换, [a,b]为最优区间
  M = max(a-min(x), max(x)-b)
  n = length(x)
  y = rep(1, n)
  for(i in 1:n) {
    if(x[i] < a)
      y[i] = 1 - (a-x[i]) / M
    else if(x[i] > b)
      y[i] = 1 - (x[i]-b) / M
  }
  y
}

Temp = c(35.2, 35.8, 36.6, 37.1, 37.8, 38.4)
IntervalType(Temp, 36, 37)

## 标准化
scale(x)                     # 标准化
scale(x, scale = FALSE)      # 中心化: 减去均值

## 归一化
rescale = function(x, type = "pos", a = 0, b = 1) {
  rng = range(x, na.rm = TRUE)
  switch(type,
         "pos" = (b - a) * (x - rng[1]) / (rng[2] - rng[1]) + a,
         "neg" = (b - a) * (rng[2] - x) / (rng[2] - rng[1]) + a)
}

x = c(1,2,3,5)
rescale(x, "pos")

## 定性指标量化

# 线性量化
df = tibble(
  x = 0:5, 
  y = seq(0, 1, by = 0.2)
)

df %>% 
  ggplot(aes(x, y)) +
  geom_line(size = 1.1, color = "steelblue") +
  geom_point(size = 3, color = "steelblue") +
  scale_x_continuous(breaks = 0:5, 
                     labels = c("O", "很不满意", "不太满意", "较满意", 
                                "满意", "很满意"))

# 偏大型量化
library(nleqslv)

f = function(x) {
  y = numeric(2)
  y[1] = 1 / (1 + x[1] * (1 - x[2])^(-2)) - 0.01
  y[2] = 1 / (1 + x[1] * (3 - x[2])^(-2)) - 0.8
  y
}

xstart = rnorm(2)
nleqslv(xstart, f)    # 1.1086211 0.8941785

g = function(x) {
  y = numeric(2)
  y[1] = x[1] * log(3) + x[2] - 0.8
  y[2] = x[1] * log(5) + x[2] - 1
  y
}

xstart = rnorm(2)
nleqslv(xstart, g)    # 0.391523 0.369868

h1 = function(x) 1 / (1 + 1.1086 * (x - 0.8942)^-2)
h2 = function(x) 0.3915 * log(x) + 0.3699

ggplot() +
  geom_function(fun = h1, xlim = c(1, 3), size = 1.2, color = "blue") +
  geom_function(fun = h2, xlim = c(3, 5), size = 1.2, color = "red")
