## 8.2 主客观赋权法

## 熵权法赋权
Entropy_Weight = function(X, index) {
  # 实现用熵权法计算各指标(列）的权重及各数据行的得分
  # X为指标数据, 一行代表一个样本, 每列对应一个指标
  # index指示向量，指示各列正向指标还是负向指标，1表示正向指标，2表示负向指标
  # s返回各行（样本）得分，w返回各列权重
  
  pos = which(index == 1)
  neg = which(index != 1)
  
  # 数据归一化
  X[,pos] = lapply(X[,pos], rescale, type = "pos", a = 0.002, b = 0.996)
  X[,neg] = lapply(X[,neg], rescale, type = "neg", a = 0.002, b = 0.996)
  
  # 计算第j个指标下，第i个样本占该指标的比重p(i,j)           
  P = data.frame(lapply(X, function(x) x / sum(x)))
  
  # 计算第j个指标的熵值e(j)
  e = sapply(P, function(x) sum(x * log(x)) *(-1/log(nrow(P))))
  
  d = 1 - e         # 计算信息熵冗余度
  w = d / sum(d)   # 计算权重向量
  
  # 计算样本得分
  s = as.vector(100 * as.matrix(X) %*% w)
  list(w=w, s=s)
}

library(readxl)
data = read_xlsx("datas/shang_datas.xlsx")

X = data[, 2:6]
ind = c(1,1,1,1,2)

Entropy_Weight(X, ind)

## 主成分赋权
PCA_Weight = function(pc) {
  # 输入参数pc为psych包的主成分分析函数principal()的返回结果
  # 返回结果为PCA权重及中间结果
  A = matrix(pc$loadings, ncol = pc$factors)
  lambda = pc$values[1:ncol(A)]
  B = A / sqrt(matrix(rep(lambda, times = nrow(A)), ncol = ncol(A), byrow = TRUE))
  varP = pc$Vaccounted[2,]
  beta = abs(B %*% varP) / sum(varP)
  w = beta / sum(beta)
  list(lambda = lambda, B = B, beta = beta[,1], w = w[,1])
}

library(psych)
df = iris[,-5]
pc = principal(df, nfactors = 2, rotate = "varimax")
PCA_Weight(pc)


