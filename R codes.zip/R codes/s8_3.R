## 8.3 理想解法

TOPSIS = function(A, w) {
  # 实现用TOPSIS法
  # A为决策矩阵, w为各指标的权重向量
  # ind指示向量, 1表示正向指标和2表示负向指标
  B = apply(A, 2, \(x) x / norm(x, "2"))   # 规范化处理
  # 加权规范矩阵
  C = apply(B, 1, \(x) w * x) |> t()
  Cstar = apply(C, 2, max)             # 按列取最大值, 求正理想解
  C0 = apply(C, 2, min)                # 按列取最小值, 求负理想解
  Sstar = apply(C, 1, \(x) norm(x - Cstar, "2"))  # 求各样本到正理想解的距离
  S0 = apply(C, 1, \(x) norm(x - C0, "2"))        # 求各样本到负理想解的距离
  f = S0 / (S0 + Sstar)                # 相对接近度
  100 * f / sum(f)                     # 归一化到[0,100]
}

library(readxl)
library(tidyverse)

df = read_xlsx("datas/20条河流水质数据.xlsx") %>% 
  set_names("ID", "O2", "PH", "germ", "nutrient")

source("DataPreProc.R")
df = df %>% 
  mutate(PH = MiddleType(PH, 7),
         germ = max(germ) - germ,
         nutrient = IntervalType(nutrient, 10, 20))

source("Entropy_Weight.R")
rlt = Entropy_Weight(df[,2:5])   # 熵权法赋权
rlt$w

TOPSIS(df[,2:5], rlt$w)

