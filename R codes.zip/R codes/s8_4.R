## DEA模型
library(tidyverse)
library(readxl)
library(deaR)

dat = read_xlsx("datas/dea_data.xlsx")
df = read_data(dat, inputs = 2:3, outputs = 4:5)

# 投入导向CCR模型
ccr_in = model_basic(df, orientation = "io", rts = "crs")
eff_ccr_in = efficiencies(ccr_in)
slack_ccr_in = slacks(ccr_in)
lambda_ccr_in = lambdas(ccr_in)
target_ccr_in = targets(ccr_in)
reference_ccr_in = references(ccr_in)
return_ccr_in = rts(ccr_in)

# 产出导向CCR模型
ccr_out = model_basic(df, orientation = "oo", rts = "crs")
eff_ccr_out = 1 / efficiencies(ccr_out)
slack_ccr_out = slacks(ccr_out)
lambda_ccr_out = lambdas(ccr_out)
target_ccr_out = targets(ccr_out)
reference_ccr_out = references(ccr_out)
return_ccr_out = rts(ccr_out)

# 投入导向BCC模型
bbc_in = model_basic(df, orientation = "io", rts = "vrs")
eff_bbc_in = efficiencies(bbc_in)
slack_bbc_in = slacks(bbc_in)
lambda_bbc_in = lambdas(bbc_in)
target_bbc_in = targets(bbc_in)
reference_bbc_in = references(bbc_in)
return_bbc_in = rts(bbc_in)

# 产出导向BCC模型
bbc_out = model_basic(df, orientation = "oo", rts = "vrs")
eff_bbc_out = 1 / efficiencies(bbc_out)
slack_bbc_out = slacks(bbc_out)
lambda_bbc_out = lambdas(bbc_out)
target_bbc_out = targets(bbc_out)
reference_bbc_out = references(bbc_out)
return_bbc_out = rts(bbc_out)

# 带非期望产出的SBM模型
df2 = read_data(dat, inputs = 2:3, outputs = 4:6, ud_outputs = 3)
sbm_ud = model_sbmeff(df2, orientation = "no", rts = "vrs")
eff_sbm_ud = efficiencies(sbm_ud)
slack_sbm_ud = slacks(sbm_ud)
lambda_sbm_ud = lambdas(sbm_ud)
target_sbm_ud = targets(sbm_ud)
reference_sbm_ud = references(sbm_ud)

# 汇总效率结果
tibble(ccr_in = eff_ccr_in, ccr_out = eff_ccr_out,
       bbc_in = eff_bbc_in, bbc_out = eff_bbc_out,
       sbm_ud = eff_sbm_ud)

