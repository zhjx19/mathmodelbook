## 9.1 模糊理论基础

library(tidyverse)
library(FuzzyR)
library(patchwork)

# 定义绘制隶属函数图形的函数
myplotmf = function(mf) {
  ggplot() +
    geom_function(fun = mf, xlim = c(0,10), 
                  color = "steelblue", size = 1.2) +
    scale_x_continuous(breaks = seq(0,10,2))
}

# 三角隶属函数
p = c(3, 6, 8)  
trimf = genmf("trimf", p)  
p1 = myplotmf(trimf)

# 梯形隶属函数
p = c(1, 5, 7, 8)   
trapmf = genmf("trapmf", p)    
p2 = myplotmf(trapmf)

p1 | p2

# 高斯隶属函数
p = c(2, 5)
gaussmf = genmf("gaussmf", p)
p3 = myplotmf(gaussmf)

# 双高斯隶属函数(自定义)
gauss2mf = function(x, params) {
  n = length(x)
  y = vector("numeric", n)
  for(i in 1:n) {
    sig1 = params[1]
    c1 = params[2]
    sig2 = params[3]
    c2 = params[4]
    if(x[i] < c1) {
      y[i] = exp(-(x[i] - c1)^2/(2 * sig1^2))
    } else if(x[i] > c2) {
      y[i] = exp(-(x[i] - c2)^2/(2 * sig2^2))
    } else {
      y[i] = 1
    }
  }
  y
}
  
p = c(1,3,3,4)
p4 = tibble(
  x = seq(0,10,0.1),
  y = gauss2mf(x, p)) %>% 
  ggplot(aes(x, y)) +
  geom_line(color = "steelblue", size = 1.2) +
  labs(xlim = c(0,10)) +
  scale_x_continuous(breaks = seq(0,10,2))

# 广义贝尔隶属函数
p = c(2, 4, 6)
gbellmf = genmf("gbellmf", p)
p5 = myplotmf(gbellmf)

p3 | p4 | p5


## 五种模糊合成

fce = function(A, R, type) {
  # 实现模糊合成算子的计算
  # A为因素集各因素的权重向量
  # R为模糊评价矩阵, 列表示各因素，行表示各评语
  # type选择模糊合成算子的类型, 1-5分别对应前文的5种不同算子
  # B返回归一化的综合评价结果
  m = nrow(R)
  n = ncol(R)  
  B = rep(0,m)
  for(j in 1:m) {
    switch(type,
    # 取小取大, 主因素决定型
    "1" = { 
      B[j] = max(apply(rbind(A, R[j,]), 2, min))
    },
    # 乘积最大，主因素突出型
    "2" = {
      B[j] = max(A * R[j,])
    },
    # 乘加, 加权平均型
    "3" = {
      B[j] = sum(A * R[j,])
    }, 
    # 取小上界和型
    "4" = {
      B[j] = min(c(1, sum(apply(rbind(A, R[j,]), 2, min))))
    },
    # 均衡平均型
    "5" = {
      r0 = sum(R[j,])
      B[j] = sum(apply(rbind(A, R[j,] / r0), 2, min))
  })}
  B / sum(B)      # 归一化
}
