## 9.2 模糊综合评价
library(FuzzyR)
library(patchwork)

A = c(0.3, 0.3, 0.3, 0.1)
R = matrix(c(0.8, 0.7, 0.6, 0.7,
             0.1, 0.2, 0.2, 0.1,
             0.1, 0.1, 0.2, 0.2), nrow = 3, byrow = TRUE)
fce(A, R, 1)

## 耕作方案模糊评价

# 粮食亩产量的隶属函数

plotmf1 = function(mf, lab) {
  tibble(
    x = 0:800,
    y = mf(x)
  ) %>% 
  ggplot(aes(x, y)) +
    geom_line(color = "steelblue", size = 1.2) +
    labs(xlim = c(0,800)) +
    scale_x_continuous(breaks = seq(0,800,100)) +
    annotate(geom = "text", x = 700, y = 0.8,
             label = lab, size = 6, color = "red")
}

# 粮食亩产量对评语"差"的隶属函数
mf11 = genmf("trapmf", c(0,0,350,450))      # 右梯形
p1 = plotmf1(mf11, "差")
  
# 粮食亩产量对评语"中"的隶属函数
mf12 = genmf("trapmf", c(250,350,450,550))  
p2 = plotmf1(mf12, "中")

# 粮食亩产量对评语"良"的隶属函数
mf13 = genmf("trapmf", c(350,450,550,650))  
p3 = plotmf1(mf13, "良")

# 粮食亩产量对评语"优"的隶属函数
mf14 = genmf("trapmf", c(450,550,800,800))   # 左梯形
p4 = plotmf1(mf14, "优")

p1 + p2 + p3 + p4

# 农产品质量的隶属函数

plotmf2 = function(mf, lab) {
  tibble(
    x = seq(0,5,0.01),
    y = mf(x)
  ) %>% 
    ggplot(aes(x, y)) +
    geom_line(color = "steelblue", size = 1.2) +
    labs(xlim = c(0,5)) +
    scale_x_continuous(breaks = 1:5) +
    annotate(geom = "text", x = 4.5, y = 0.8,
             label = lab, size = 6, color = "red")
}

# 农产品质量对评语"差"的隶属函数
mf21 = genmf("trapmf", c(3.5,4,5,5))      # 左梯形
p5 = plotmf2(mf21, "差")

# 农产品质量对评语"中"的隶属函数
mf22 = genmf("trimf", c(2.5,3,3.5))  
p6 = plotmf2(mf22, "中")

# 农产品质量对评语"良"的隶属函数
mf23 = genmf("trimf", c(1.5,2,2.5))  
p7 = plotmf2(mf23, "良")

# 农产品质量对评语"优"的隶属函数
mf24 = genmf("trapmf", c(0,0,1,1.5))     # 右梯形
p8 = plotmf2(mf24, "优")

p5 + p6 + p7 + p8

mf31 = genmf("trapmf", c(40,60,80,80))
mf32 = genmf("trapmf", c(20,40,60,80))
mf33 = genmf("trapmf", c(0,20,40,60))
mf34 = genmf("trapmf", c(0,0,20,40))
mf41 = genmf("trapmf", c(0,0,50,90))
mf42 = genmf("trapmf", c(0,50,90,130))
mf43 = genmf("trapmf", c(50,90,130,170))
mf44 = genmf("trapmf", c(90,130,170,170))
mf51 = genmf("trapmf", c(3.5,4,5,5))
mf52 = genmf("trimf", c(2.5,3,3.5))
mf53 = genmf("trimf", c(1.5,2,2.5))
mf54 = genmf("trapmf", c(0,0,1,1.5))

df = tibble(
  product = c(592.5, 529, 412),
  quality = 3:1,
  labor = c(55, 38, 32),
  income = c(72, 105, 85),
  ecology = 4:2)

CalFEM = function(x) {
  # x为一种耕作方案的各指标值构成的向量
  matrix(c(mf11(x[[1]]), mf21(x[[2]]), mf31(x[[3]]), mf41(x[[4]]), mf51(x[[5]]),
           mf12(x[[1]]), mf22(x[[2]]), mf32(x[[3]]), mf42(x[[4]]), mf52(x[[5]]),
           mf13(x[[1]]), mf23(x[[2]]), mf33(x[[3]]), mf43(x[[4]]), mf53(x[[5]]),
           mf14(x[[1]]), mf24(x[[2]]), mf34(x[[3]]), mf44(x[[4]]), mf54(x[[5]])),
         nrow = 4, byrow = TRUE)
}
  
R1 = CalFEM(df[1,])
R2 = CalFEM(df[2,])
R3 = CalFEM(df[3,])

A = c(0.2, 0.1, 0.15, 0.3, 0.25)

type = 3                         # 选择加权平均型
B1 = fce(A, R1, type)
B1
B2 = fce(A, R2, type)
B2
B3 = fce(A, R3, type)
B3

w = c(30, 60, 75, 90)
sum(w * B1)
sum(w * B2)
sum(w * B3)

