## 9.3 灰色关联分析
library(tidyverse)
library(readxl)

gray_corr = function(ck, bj, rho, w = NULL) {
  # 计算灰色关联度
  # ck为参考序列, bj为比较序列, rho为分辨系数
  # w为加权关联度的权重向量
  n = nrow(bj)
  if(is.null(w)) {
    w = rep(1/n, n)
  }
  t = apply(bj, 2, \(x) x - ck)
  min2 = min(apply(abs(t), 2, min))       # 求两级最小差
  max2 = max(apply(abs(t), 2, max))       # 求两级最大差
  eta = (min2 + rho*max2) / (abs(t) + rho*max2)  # 求关联系数
  r = w %*% eta
  r[1,]
}
 
df = read_xlsx("datas/sport_datas.xlsx")

df = df %>% 
  mutate(across(2:16, ~ .x / .x[1]),
         across(17:18, ~ .x[1] / .x))

ck = df$铅球成绩x0
bj = df[,3:18]
rho = 0.5
gray_corr(ck, bj, rho)

## 优势分析
df = read_xlsx("datas/economy_datas.xlsx")

df = df %>% 
  mutate(across(2:12, ~ .x / .x[1]))

map_dfr(df[7:12], ~ gray_corr(.x, df[2:6], 0.5))

## 灰色关联评价
gray_corr_eval = function(A, w, rho = 0.5) {
  # 实现用灰色关联评价
  # A为决策矩阵, w为各指标的权重向量
  # rho为灰色关联的分辨系数
  n = nrow(A)
  m = ncol(A)
  B = apply(A, 2, \(x) x / norm(x, "2"))   # 规范化处理
  # 加权规范矩阵
  C = as.matrix(B) * matrix(rep(w,n), byrow = TRUE, ncol = m) 
  ck = apply(C, 2, max)
  f = gray_corr(ck, t(C), rho)
  100 * f / sum(f)                         # 归一化
}

df = read_xlsx("datas/20条河流水质数据.xlsx") %>% 
  set_names("ID", "O2", "PH", "germ", "nutrient")

df = df %>% 
  mutate(PH = MiddleType(PH, 7),
         germ = max(germ) - germ,
         nutrient = IntervalType(nutrient, 10, 20))

gray_corr_eval(df[2:5], rlt$w)
